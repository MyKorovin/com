package labSE1;

import java.io.IOException;

public class Specialty {
	

	
	private String name;
	private Faculty faculty;

	public Faculty getFaculty() {
		return faculty;
	}

	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}

	private Course[] courses = new Course[6];
	private int numberOfStudentsOnSpecialty;
	
	public int getNumberOfStudentsOnSpecialty() {
		return numberOfStudentsOnSpecialty;
	}

	public void setNumberOfStudentsOnSpecialty(int numberOfStudentsOnSpecialty) {
		this.numberOfStudentsOnSpecialty = numberOfStudentsOnSpecialty;
	}

	/**конструктор без параметрів, встановлює назву спеціальності та додає 6 курсів на спеціальність 
	 * @throws IOException
	 */
	public Specialty(Faculty faculty) throws IOException {
		name = DataInput.takeInputString("Введіть назву спеціальності: ");
		this.faculty = faculty;
		addCourses();
	}
	
	/**додає 6 курсів
	 * 
	 */
	private void addCourses() {
		for (int i = 0; i < 6; i ++) {
			courses[i] = new Course(i+1, this);
		}
	}
	

	/**перевіряє, чи є студенти на спеціальності
	 * @param specialty
	 * @return
	 */
	public static boolean studentsPresent(Specialty specialty) {
		int num = 0;
		for (Course course: specialty.getCourses()) {
			for (Group group: course.getGroups()) {
				num += group.getNumberOfStudents();
			}
		}
		if (num != 0) {
			return true;
		}
		System.out.println();
		System.out.println("Не додано жодного студента!");
		return false;
	}
	/**повертає назву спеціальності
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**встановлює назву спеціальності
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**повертає масив курсів спеціальності
	 * @return
	 */
	public Course[] getCourses() {
		return courses;
	}

	/**встановлює масив курсів
	 * @param courses
	 */
	public void setCourses(Course[] courses) {
		this.courses = courses;
	}

}

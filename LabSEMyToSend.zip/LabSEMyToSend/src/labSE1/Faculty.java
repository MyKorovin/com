package labSE1;

import java.io.IOException;
import java.util.Arrays;

/**
 * @author illia_sitkov
 *
 */
public class Faculty {

	private Specialty[] specialties = new Specialty[0];
	private Cathedra[] cathedras = new Cathedra[0];

	private String name;

	public static int numberOfFaculties;

	private int numberOfStudentsInFaculty;
	private int numberOfSpecialties = specialties.length;
	private int numberOfCathedras = cathedras.length;

	public Faculty(String name) {
		this.name = name;
		numberOfFaculties++;
	}

	/**перевіряє факультети на рівність
	 * @param faculty
	 * @return
	 */
	public boolean equals(Faculty faculty) {
		if (faculty != null) {
			if (this.name.equals(faculty.getName())) {
				return true;
			}
		}
		return false;
	}

	/**перевіряє, чи є кафедри
	 * @param faculty
	 * @return
	 */
	public static boolean cathedrasPresent(Faculty faculty) {
		if (faculty.getCathedras().length != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодної кафедри!");
		}
		return false;
	}

	/**перевіряє, чи є спеціальності
	 * @param faculty
	 * @return
	 */
	public static boolean specialtiesPresent(Faculty faculty) {
		if (faculty.getSpecialties().length != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодної спеціальності!");
		}
		return false;
	}

	/**рахує ксть викладачів на факультеті
	 * @param faculty
	 * @return
	 */
	private int calcNumberOfTeachersInFaculty(Faculty faculty) {
		int num = 0;
		for (Cathedra cathedra : faculty.getCathedras()) {
			num += cathedra.getNumberOfTeachers();
		}
		return num;
	}

	/**рахує ксть студентів на факультеті
	 * @param faculty
	 * @return
	 */
	private int calcNumberOfStudentsInFaculty(Faculty faculty) {
		int num = 0;
		for (Specialty specialty : faculty.getSpecialties()) {
			for (Course course : specialty.getCourses()) {
				for (Group group : course.getGroups()) {
					num += group.getNumberOfStudents();
				}
			}

		}
		return num;
	}

	/**перевіряє, чи є на факультеті вчителі
	 * @param faculty
	 * @return
	 */
	public static boolean teachersPresent(Faculty faculty) {
		if (faculty.calcNumberOfTeachersInFaculty(faculty) != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодного викладача!");
		}
		return false;
	}

	/**перевіряє, чи є на факультеті студенти
	 * @param faculty
	 * @return
	 */
	public static boolean studentsPresent(Faculty faculty) {
		if (faculty.calcNumberOfStudentsInFaculty(faculty) != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодного студента!");
		}
		return false;
	}

	/**
	 * конструктор без параметрів, що встановлює назвою факультету введену
	 * користувачем стрічку
	 * 
	 * @throws IOException
	 */
	public Faculty() throws IOException {
		name = DataInput.takeInputString("Введіть назву факультету: ");
	}

	//////////////////////////////////////////////////////////
	private void calculateNumbers() {
		numberOfStudentsInFaculty = 0;
		for (Specialty specialty : specialties) {
			for (Course course : specialty.getCourses()) {
				for (Group group : course.getGroups()) {
					numberOfStudentsInFaculty += group.getStudents().length;
				}
			}
		}
		numberOfSpecialties = specialties.length;
		numberOfCathedras = cathedras.length;
	}

	/**
	 * запитує факультет, на який потрібно додати спеціальність
	 * 
	 * @param prompt
	 * @throws IOException
	 */
	public static void askForFaculty(String prompt) throws IOException {
		if (University.facultiesPresent()) {
			University.printAllFaculties();
			Faculty neededFaculty = null;
			String name = DataInput.takeInputString(prompt);
			Faculty[] faculties = University.getFaculties();
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					neededFaculty = faculty;
					break;
				}
			}
			if (neededFaculty != null) {
				addSpecialty(neededFaculty);
			} else {
				System.out.println();
				System.out.println("Факультету з такою назвою не знайдено!");
			}
		}
	}

	/**
	 * запитує факультет, на якому потрібно змінити спеціальність
	 * 
	 * @param prompt
	 * @throws IOException
	 */
	public static void askForFacultyToRename(String prompt) throws IOException {
		if (University.facultiesPresent() && University.specialtiesPresent()) {
			University.printAllFaculties();
			Faculty neededFaculty = null;
			String name = DataInput.takeInputString(prompt);
			Faculty[] faculties = University.getFaculties();
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					neededFaculty = faculty;
					break;
				}
			}
			if (neededFaculty != null && specialtiesPresent(neededFaculty)) {
				changeNameOfSpecialty(neededFaculty);
			} else if (neededFaculty == null){
				System.out.println();
				System.out.println("Факультету з такою назвою не знайдено!");
			}
		}
	}

	/**
	 * запитує факультет, на якому потрібно видалити спеціальність
	 * 
	 * @param prompt
	 * @throws IOException
	 */
	public static void askForFacultyToDelete(String prompt) throws IOException {
		if (University.facultiesPresent() && University.specialtiesPresent()) {
			University.printAllFaculties();
			Faculty neededFaculty = null;
			String name = DataInput.takeInputString(prompt);
			Faculty[] faculties = University.getFaculties();
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					neededFaculty = faculty;
					break;
				}
			}
			if (neededFaculty != null && specialtiesPresent(neededFaculty)) {
				deleteSpecialty(neededFaculty);
			} else if (neededFaculty == null){
				System.out.println();
				System.out.println("Факультету з такою назвою не знайдено!");
			}
		}
	}

	/**
	 * додає спеціальність на факультет
	 * 
	 * @param faculty
	 * @throws IOException
	 */
	private static void addSpecialty(Faculty faculty) throws IOException {
		Specialty[] specialties = faculty.getSpecialties();
		while (true) {
			Specialty[] temp = specialties;
			specialties = new Specialty[specialties.length + 1];
			specialties[faculty.getNumberOfSpecialties()] = new Specialty(faculty);
			String name = specialties[faculty.getNumberOfSpecialties()].getName();
			while (Faculty.areDifferent(temp, name) == false) {
				name = DataInput.takeInputString("Така спеціальність вже існує! Введіть нову спеціальність: ");
			}
			specialties[faculty.getNumberOfSpecialties()].setName(name);
			faculty.setNumberOfSpecialties(faculty.getNumberOfSpecialties() + 1);
			for (int i = 0; i < temp.length; i++) {
				specialties[i] = temp[i];
			}
			String prod = DataInput.takeInputString("Продовжити введення? так/ні ");
			if (prod.charAt(0) == 'н')
				break;
		}
		faculty.setSpecialties(specialties);
		printAllSpecialties(faculty);
	}

	/**
	 * видаляє спеціальність з факультету
	 * 
	 * @param faculty
	 * @throws IOException
	 */
	private static void deleteSpecialty(Faculty faculty) throws IOException {
		printAllSpecialties(faculty);
		Specialty[] specialties = faculty.getSpecialties();
		boolean found = false;
		boolean delete = true;
		String name = DataInput.takeInputString("Введіть назву спеціальності, яку потрібно видалити: ");
		for (Specialty specialty : specialties) {
			if (specialty.getName().equals(name)) {
				System.out.println();
				System.out.println(
						"Разом зі спеціальністю буде ВИДАЛЕНО ВСІ курси, групи та записаних до них студентів!");
				System.out.print("Точно бажаєте ВИДАЛИТИ спеціальність? (так/ні): ");
				String conf = DataInput.getString();
				if (conf.charAt(0) == 'н') {
					delete = false;
					break;
				}
				System.out.println();
				System.out.print("Спеціальність видалено");
				System.out.println();
				specialties[Arrays.asList(specialties).indexOf(specialty)] = null;
				faculty.setSpecialties(resortSpecialties(specialties));
				found = true;
				faculty.setNumberOfSpecialties(faculty.getNumberOfSpecialties() - 1);
				printAllSpecialties(faculty);
				break;
			}
		}
		if (found == false && delete == true) {
			System.out.println();
			System.out.println("Спеціальності з такою назвою не знайдено!");
		}
	}

	/**
	 * сортує спеціальності після видалення
	 * 
	 * @param specialties
	 * @return
	 */
	private static Specialty[] resortSpecialties(Specialty[] specialties) {
		Specialty[] temp = specialties;
		specialties = new Specialty[0];
		for (int i = 0, j = 0; i < temp.length; i++) {
			if (temp[i] != null) {
				Specialty[] temp1 = specialties;
				specialties = new Specialty[specialties.length + 1];
				specialties[j] = temp[i];
				for (int k = 0; k < temp1.length; k++) {
					specialties[k] = temp1[k];
				}
				j++;
			}
		}
		return specialties;
	}

	/**
	 * змінює назву спеціальності
	 * 
	 * @param faculty
	 * @throws IOException
	 */
	private static void changeNameOfSpecialty(Faculty faculty) throws IOException {
		Specialty[] specialties = faculty.getSpecialties();
		printAllSpecialties(faculty);
		boolean found = false;
		String name = DataInput.takeInputString("Введіть назву спеціальності, яку потрібно перейменувати: ");
		for (Specialty specialty : specialties) {
			if (specialty.getName().equals(name)) {
				specialty.setName("");
				String newName = DataInput.takeInputString("Введіть нову назву спеціальності: ");
				while (areDifferent(specialties, newName) == false) {
					newName = DataInput
							.takeInputString("Така спеціальність вже існує! Введіть нову назву спеціальності: ");
				}
				specialty.setName(newName);
				renewNameOfSpecialtyInStudents(specialty);
				found = true;
				printAllSpecialties(faculty);
				break;
			}
		}
		if (found == false) {
			System.out.println();
			System.out.println("Спеціальності з такою назвою не знайдено!");
		}
	}

	/**
	 * перейменовує назву спеціальності в студентів після зміни назви спеціальності
	 * 
	 * @param specialty
	 */
	private static void renewNameOfSpecialtyInStudents(Specialty specialty) {
		for (Course course : specialty.getCourses()) {
			for (Group group : course.getGroups()) {
				for (Student student : group.getStudents()) {
					student.setSpecialty(specialty.getName());
				}
			}
		}

	}

	/**
	 * перевіряє, чи вже існує спеціальність з такою самою назвою
	 * 
	 * @param specialties
	 * @param name
	 * @return
	 */
	public static boolean areDifferent(Specialty[] specialties, String name) {
		for (Specialty specialty : specialties) {
			if (name.equals(specialty.getName())) {
				return false;
			}
		}
		return true;
	}

	/**
	 * перевіряє, чи вже існує факультет з такою самою назвою
	 * 
	 * @param faculties
	 * @param name
	 * @return
	 */
	public static boolean areDifferent(Faculty[] faculties, String name) {
		for (Faculty faculty : faculties) {
			if (name.equals(faculty.getName())) {
				return false;
			}
		}
		return true;
	}

	/**
	 * друкує всі спеціальності факультету
	 * 
	 * @param faculty
	 */
	public static void printAllSpecialties(Faculty faculty) {
		Specialty[] specialties = faculty.getSpecialties();
		System.out.println();
		System.out.println("Список спеціальностей факультету " + faculty.getName() + ": ");
		for (Specialty s : specialties) {
			if (s != null)
				System.out.println((Arrays.asList(specialties).indexOf(s) + 1) + ". " + s.getName());
		}
		if (specialties.length == 0) {
			System.out.println("Не додано жодної спеціальності");
		}
	}

	//////////////////////////////////////////////////////////////////////////////////

	/**
	 * запитує факультет, на який потрібно додати кафедру
	 * 
	 * @param prompt
	 * @throws IOException
	 */
	public static void askForFacultyCathedra(String prompt) throws IOException {
		if (University.facultiesPresent()) {
			University.printAllFaculties();
			Faculty neededFaculty = null;
			String name = DataInput.takeInputString(prompt);
			Faculty[] faculties = University.getFaculties();
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					neededFaculty = faculty;
					break;
				}
			}
			if (neededFaculty != null) {
				addCathedra(neededFaculty);
			} else {
				System.out.println();
				System.out.println("факультету з такою назвою не знайдено!");
			}
		}
	}

	/**
	 * додає кафедри на факультет
	 * 
	 * @param faculty
	 * @throws IOException
	 */
	private static void addCathedra(Faculty faculty) throws IOException {
		Cathedra[] cathedras = faculty.getCathedras();
		while (true) {
			Cathedra[] temp = cathedras;
			cathedras = new Cathedra[cathedras.length + 1];
			cathedras[faculty.getNumberOfCathedras()] = new Cathedra();
			String name = cathedras[faculty.getNumberOfCathedras()].getName();
			while (Faculty.areDifferent(temp, name) == false) {
				name = DataInput.takeInputString("Така кафедра вже існує! Введіть нову кафедру: ");
			}
			cathedras[faculty.getNumberOfCathedras()].setName(name);
			faculty.setNumberOfCathedras(faculty.getNumberOfCathedras() + 1);
			for (int i = 0; i < temp.length; i++) {
				cathedras[i] = temp[i];
			}
			String prod = DataInput.takeInputString("Продовжити введення? так/ні ");
			if (prod.charAt(0) == 'н')
				break;
		}
		faculty.setCathedras(cathedras);
		printAllCathedras(faculty);
	}

	/**
	 * запитує факультет, на якому потрібно змінити кафедру
	 * 
	 * @param prompt
	 * @throws IOException
	 */
	public static void askForFacultyToRenameCathedra(String prompt) throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent()) {
			University.printAllFaculties();
			Faculty neededFaculty = null;
			String name = DataInput.takeInputString(prompt);
			Faculty[] faculties = University.getFaculties();
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					neededFaculty = faculty;
					break;
				}
			}
			if (neededFaculty != null && cathedrasPresent(neededFaculty)) {
				changeNameOfCathedra(neededFaculty);
			} else if (neededFaculty == null){
				System.out.println();
				System.out.println("Факультету з такою назвою не знайдено!");
			}
		}
	}

	/**
	 * змінює назву кафедри
	 * 
	 * @param faculty
	 * @throws IOException
	 */
	private static void changeNameOfCathedra(Faculty faculty) throws IOException {
		Cathedra[] cathedras = faculty.getCathedras();
		printAllCathedras(faculty);
		boolean found = false;
		String name = DataInput.takeInputString("Введіть назву кафедри, яку потрібно перейменувати: ");
		for (Cathedra cathedra : cathedras) {
			if (cathedra.getName().equals(name)) {
				cathedra.setName("");
				String newName = DataInput.takeInputString("Введіть нову назву кафедри: ");
				while (areDifferent(cathedras, newName) == false) {
					newName = DataInput.takeInputString("Така кафедра вже існує! Введіть нову назву кафедри: ");
				}
				cathedra.setName(newName);
				renewNameOfCathedraInTeachers(cathedra);
				found = true;
				printAllCathedras(faculty);
				break;
			}
		}
		if (found == false) {
			System.out.println();
			System.out.println("Кафедри з такою назвою не знайдено!");
		}
	}

	/**
	 * перейменовує назву кафедри у викладачів після зміни назви кафедри
	 * 
	 * @param cathedra
	 */
	private static void renewNameOfCathedraInTeachers(Cathedra cathedra) {
		for (Teacher teacher : cathedra.getTeachers()) {
			teacher.setCathedra(cathedra.getName());
		}
	}

	/**
	 * запитує факультет, на якому потрібно видалити кафедру
	 * 
	 * @param prompt
	 * @throws IOException
	 */
	public static void askForFacultyToDeleteCathedra(String prompt) throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent()) {
			University.printAllFaculties();
			Faculty neededFaculty = null;
			String name = DataInput.takeInputString(prompt);
			Faculty[] faculties = University.getFaculties();
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					neededFaculty = faculty;
					break;
				}
			}
			if (neededFaculty != null && cathedrasPresent(neededFaculty)) {
				deleteCathedra(neededFaculty);
			} else if (neededFaculty == null){
				System.out.println();
				System.out.println("Факультету з такою назвою не знайдено!");
			}

		}
	}

	/**
	 * видаляє кафедру
	 * 
	 * @param faculty
	 * @throws IOException
	 */
	private static void deleteCathedra(Faculty faculty) throws IOException {
			printAllCathedras(faculty);
			Cathedra[] cathedras = faculty.getCathedras();
			boolean found = false;
			boolean delete = true;
			String name = DataInput.takeInputString("Введіть назву кафедри, яку потрібно видалити: ");
			for (Cathedra cathedra : cathedras) {
				if (cathedra.getName().equals(name)) {
					System.out.println();
					System.out.println("Разом з кафедрою буде ВИДАЛЕНО ВСІХ викладачів!");
					System.out.print("Точно бажаєте ВИДАЛИТИ кафедру? (так/ні): ");
					String conf = DataInput.getString();
					if (conf.charAt(0) == 'н') {
						delete = false;
						break;
					}
					System.out.println();
					System.out.print("Кафедру видалено");
					System.out.println();
					cathedras[Arrays.asList(cathedras).indexOf(cathedra)] = null;
					faculty.setCathedras(resortCathedras(cathedras));
					found = true;
					faculty.setNumberOfCathedras(faculty.getNumberOfCathedras() - 1);
					printAllCathedras(faculty);
					break;
				}
			}
			if (found == false && delete == true) {
				System.out.println();
				System.out.println("Кафедри з такою назвою не знайдено!");
			}
	}

	/**збирає в масив усіх студентів факультету
	 * @param faculty
	 * @return
	 */
	
	public static Student[] collectAllStudentsOfFaculty(Faculty faculty) {
		int num = 0;
		for (Specialty sp : faculty.getSpecialties()) {
			for (Course c : sp.getCourses()) {
				for (Group g : c.getGroups()) {
					num += g.getNumberOfStudents();
				}
			}
		}
		Student[] studentsToSort = new Student[num];
		int i = 0;
		for (Specialty sp : faculty.getSpecialties()) {
			for (Course c : sp.getCourses()) {
				for (Group g : c.getGroups()) {
					for (Student s : g.getStudents()) {
						studentsToSort[i] = s;
						i++;
					}
				}
			}
		}
		return studentsToSort;
	}
	

	
	/**
	 * сортує кафедри після видалення
	 * 
	 * @param cathedras
	 * @return
	 */
	private static Cathedra[] resortCathedras(Cathedra[] cathedras) {
		Cathedra[] temp = cathedras;
		cathedras = new Cathedra[0];
		for (int i = 0, j = 0; i < temp.length; i++) {
			if (temp[i] != null) {
				Cathedra[] temp1 = cathedras;
				cathedras = new Cathedra[cathedras.length + 1];
				cathedras[j] = temp[i];
				for (int k = 0; k < temp1.length; k++) {
					cathedras[k] = temp1[k];
				}
				j++;
			}
		}
		return cathedras;
	}

	/**
	 * перевіряє, чи вже існує кафедра з тою самою назвою
	 * 
	 * @param cathedras
	 * @param name
	 * @return
	 */
	public static boolean areDifferent(Cathedra[] cathedras, String name) {
		for (Cathedra cathedra : cathedras) {
			if (name.equals(cathedra.getName())) {
				return false;
			}
		}
		return true;
	}

	/**
	 * друкує всі кафедри факультету
	 * 
	 * @param faculty
	 */
	public static void printAllCathedras(Faculty faculty) {
		Cathedra[] cathedras = faculty.getCathedras();
		System.out.println();
		System.out.println("Список кафедр факультету " + faculty.getName() + ": ");
		for (Cathedra c : cathedras) {
			if (c != null)
				System.out.println((Arrays.asList(cathedras).indexOf(c) + 1) + ". " + c.getName());
		}
		if (cathedras.length == 0) {
			System.out.println("Не додано жодної кафедри");
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////
	
	                
	    
	
	
	
	public static Teacher[] getTeachersOfFaculty(Faculty faculty) {
		int num = 0;
		for (Cathedra cathedra: faculty.getCathedras()) {
			num += cathedra.getNumberOfTeachers();
		}
		Teacher[] teachersToSort = new Teacher[num];
		int i = 0;
		for (Cathedra cathedra: faculty.getCathedras()) {
			for (Teacher teacher: cathedra.getTeachers()) {
				teachersToSort[i] = teacher;
				i++;
			}
		}
		return teachersToSort;
	}
	
	public static Student[] createArrayOfStudentsOfFaculty(Faculty faculty) {
		int num = 0;
		for (Specialty sp : faculty.getSpecialties()) {
			for (Course c : sp.getCourses()) {
				for (Group g : c.getGroups()) {
					num += g.getNumberOfStudents();
				}
			}
		}
		Student[] studentsToSort = new Student[num];
		int i = 0;
		for (Specialty sp : faculty.getSpecialties()) {
			for (Course c : sp.getCourses()) {
				for (Group g : c.getGroups()) {
					for (Student s : g.getStudents()) {
						studentsToSort[i] = s;
						i++;
					}
				}
			}
		}
		return studentsToSort;
	}
////////////////////////////////////////////////////////////////////////////////////////////	
	
			public static void printAllStudentsOfSpecialtySortedByNames() throws IOException{
			    
			    if (University.getFaculties().length != 0) {
			      University.printAllFaculties();
			      boolean foundFaculty = false;
			      String nameF = DataInput.takeInputString("Введіть назву факультета для пошуку спеціальності: ");
			      for (Faculty faculty : University.getFaculties()) {
			        if (faculty.getName().equals(nameF)) {
			          if (faculty.getNumberOfSpecialties() != 0) {
			            if (faculty.getNumberOfStudentsOnFaculty() != 0){ //есть метод Faculty.studentsPresent(Faculty faculty)
			              printAllSpecialties(faculty);
			              boolean foundSpecialty = false;
			              String nameS = DataInput.takeInputString("Введіть назву спеціальності для виведення студентів за алфавітом: ");
			              Student students[] = University.sortStudentsbyNames(createArrayOfStudentsOfFaculty(faculty));
			              for (Specialty specialty: faculty.getSpecialties()){
			                if (specialty.getName().equals(nameS)) {
			                  if (specialty.getNumberOfStudentsOnSpecialty() != 0){
			                    System.out.println("Список студентів спеціальності " + specialty.getName() + " за алфавітом: ");
			                    System.out.println();
			                    int numberOfStudent = 1;
			                    for (Student student : students) {
			                      if (student != null){
			                        if (student.getSpecialty().equals(nameS)){
			                          System.out.println(numberOfStudent + ". " + student.toString());
			                          numberOfStudent++;
			                        }
			                      }    
			                    }
			                  }
			                  else {
			                    System.out.println();
			                    System.out.println("На спеціальність не додано жодного студента!");
			                  }
			                  foundSpecialty = true;
			                  break;
			                }  
			              }
			              if (foundSpecialty == false) {
			                System.out.println();
			                System.out.println("Спеціальності з такою назвою не знайдено!");
			              }    
			            } else {
			              System.out.println();
			              System.out.println("На факультет не додано жодного студента!");
			            }
			          }
			          else {
			            System.out.println();
			            System.out.println("На факультеті немає жодної спеціальності! Спочатку додайте спеціальність!");
			          }  
			          foundFaculty = true;
			          break;
			        }  
			      }
			      if (foundFaculty == false) {
			        System.out.println();
			        System.out.println("Факультета з такою назвою не знайдено!");
			      } 
			    }  
			    else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }    
			  }
			    
			public static void printAllStudentsOfSpecialtyOfNeededCourseSortedByNames() throws IOException{
			    
			    if (University.getFaculties().length != 0) {
			      University.printAllFaculties();
			      boolean foundFaculty = false;
			      String nameF = DataInput.takeInputString("Введіть назву факультета для пошуку спеціальності: ");
			      for (Faculty faculty : University.getFaculties()) {
			        if (faculty.getName().equals(nameF)) {
			          if (faculty.getNumberOfSpecialties() != 0) {//есть метод Faculty.specialtiesPresent(Faculty faculty)
			            if (faculty.getNumberOfStudentsOnFaculty() != 0){//есть метод Faculty.studentsPresent(Faculty faculty)
			              printAllSpecialties(faculty);
			              boolean foundSpecialty = false;
			              String nameS = DataInput.takeInputString("Введіть назву спеціальності для виведення студентів за алфавітом: ");
			              Student students[] = University.sortStudentsbyNames(createArrayOfStudentsOfFaculty(faculty));
			              for (Specialty specialty: faculty.getSpecialties()){
			                if (specialty.getName().equals(nameS)) {
			                  if (specialty.getNumberOfStudentsOnSpecialty() != 0){
			                    Course course = Group.askForCourse(specialty, "Введіть курс (1 - 6), студентів якого потрібно вивести за алфавітом: ");
			                    if (course.getNumberOfStudentsOnCourse() != 0){

			
			System.out.println("Список студентів спеціальності " + specialty.getName() + " " + course.getCourse() + " курсу за алфавітом: ");
			                      System.out.println();
			                      int numberOfStudent = 1;
			                      for (Student student : students) {
			                        if (student != null){
			                          if (student.getSpecialty().equals(nameS)){
			                            if (student.getCourse() == course.getCourse()){
			                              System.out.println(numberOfStudent + ". " + student.toString());
			                              numberOfStudent++;
			                            }
			                          }
			                        }    
			                      }
			                    }
			                    else {
			                      System.out.println();
			                      System.out.println("На курс не додано жодного студента!");
			                    }
			                  }
			                  else {
			                    System.out.println();
			                    System.out.println("На спеціальність не додано жодного студента!");
			                  }
			                  foundSpecialty = true;
			                  break;
			                }  
			              }
			              if (foundSpecialty == false) {
			                System.out.println();
			                System.out.println("Спеціальності з такою назвою не знайдено!");
			              }    
			            } else {
			              System.out.println();
			              System.out.println("На факультет не додано жодного студента!");
			            }
			          }
			          else {
			            System.out.println();
			            System.out.println("На факультеті немає жодної спеціальності! Спочатку додайте спеціальність!");
			          }  
			          foundFaculty = true;
			          break;
			        }  
			      }
			      if (foundFaculty == false) {
			        System.out.println();
			        System.out.println("Факультета з такою назвою не знайдено!");
			      } 
			    }  
			    else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }    
			  }

			
			public static void printAllStudentsOfSpecialtySortedByCourses() throws IOException{
			  
			  if (University.getFaculties().length != 0) {
			    University.printAllFaculties();
			    boolean foundFaculty = false;
			    String nameF = DataInput.takeInputString("Введіть назву факультета для пошуку спеціальності: ");
			    for (Faculty faculty : University.getFaculties()) {
			      if (faculty.getName().equals(nameF)) {
			        if (faculty.getNumberOfSpecialties() != 0) {//есть метод Faculty.specialtiesPresent(Faculty faculty)
			          if (faculty.getNumberOfStudentsOnFaculty() != 0){//есть метод Faculty.studentsPresent(Faculty faculty)
			            printAllSpecialties(faculty);
			            boolean foundSpecialty = false;
			            String nameS = DataInput.takeInputString("Введіть назву спеціальності для виведення студентів за курсами: ");
			            for (Specialty specialty: faculty.getSpecialties()){
			              if (specialty.getName().equals(nameS)) {
			                if (specialty.getNumberOfStudentsOnSpecialty() != 0){
			                  System.out.println("Список студентів спеціальності " + specialty.getName() + " за курсами: ");
			                  for (int i = 1; i <= 6; i++){
			                    System.out.println();
			                    System.out.println("Студенти " + i + " курсу:");
			                    System.out.println();
			                    int numberOfStudent = 1;
			                    for (Course course : specialty.getCourses()) {
			                      if (course.getCourse() == i){
			                        for (Group group : course.getGroups()) {
			                          for (Student student : group.getStudents()) {
			                            System.out.println(numberOfStudent + ". " + student.toString());
			                            numberOfStudent++;
			                          }
			                        }
			                      }  
			                    }      
			                  }
			                }
			                else {
			                  System.out.println();
			                  System.out.println("На спеціальність не додано жодного студента!");
			                }
			                foundSpecialty = true;
			                break;
			              }  
			            }
			            if (foundSpecialty == false) {
			              System.out.println();
			              System.out.println("Спеціальності з такою назвою не знайдено!");
			            }    
			          } else {
			            System.out.println();
			            System.out.println("На факультет не додано жодного студента!");
			          }
			        }
			        else {
			          System.out.println();
			          System.out.println("На факультеті немає жодної спеціальності! Спочатку додайте спеціальність!");
			        }  
			        foundFaculty = true;
			        break;
			      }  
			    }
			    if (foundFaculty == false) {
			      System.out.println();
			      System.out.println("Факультета з такою назвою не знайдено!");
			    } 
			  }  
			  else {
			    System.out.println();
			    System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			  }    
			}

			public static void printAllStudentsOfSpecialtyOfNeededCourse() throws IOException{
			  
			  if (University.getFaculties().length != 0) {
			    University.printAllFaculties();
			    boolean foundFaculty = false;
			    String nameF = DataInput.takeInputString("Введіть назву факультета для пошуку спеціальності: ");
			    for (Faculty faculty : University.getFaculties()) {
			      if (faculty.getName().equals(nameF)) {
			        if (faculty.getNumberOfSpecialties() != 0) {//есть метод Faculty.specialtiesPresent(Faculty faculty)
			          if (faculty.getNumberOfStudentsOnFaculty() != 0){//есть метод Faculty.studentsPresent(Faculty faculty)
			            printAllSpecialties(faculty);
			            boolean foundSpecialty = false;
			            String nameS = DataInput.takeInputString("Введіть назву спеціальності для виведення студентів: ");
			            for (Specialty specialty: faculty.getSpecialties()){
			              if (specialty.getName().equals(nameS)) {
			                if (specialty.getNumberOfStudentsOnSpecialty() != 0){
			                  Course course = Group.askForCourse(specialty, "Введіть курс (1 - 6), студентів якого потрібно вивести: ");
			                  if (course.getNumberOfStudentsOnCourse() != 0){
			                    System.out.println("Список студентів спеціальності " + specialty.getName() + " " + course.getCourse() + " курсу: ");
			                    System.out.println();
			                    int numberOfStudent = 1;
			                    for (Group group : course.getGroups()) {
			                      for (Student student : group.getStudents()) {
			                        System.out.println(numberOfStudent + ". " + student.toString());
			                        numberOfStudent++;
			                      }
			                    }      
			                  }
			                  else {
			                    System.out.println();
			                    System.out.println("На курс не додано жодного студента!");
			                  }
			                }
			                else {
			                  System.out.println();
			                  System.out.println("На спеціальність не додано жодного студента!");
			                }
			                foundSpecialty = true;
			                break;
			              }  
			            }
			            if (foundSpecialty == false) {
			              System.out.println();
			              System.out.println("Спеціальності з такою назвою не знайдено!");
			            }    
			          } else {
			            System.out.println();
			            System.out.println("На факультет не додано жодного студента!");
			          }
			        }
			        else {
			          System.out.println();
			          System.out.println("На факультеті немає жодної спеціальності! Спочатку додайте спеціальність!");
			        }  
			        foundFaculty = true;
			        break;
			      }  
			    }
			    if (foundFaculty == false) {
			      System.out.println();
			      System.out.println("Факультета з такою назвою не знайдено!");
			    } 
			  }  
			  else {
			    System.out.println();
			    System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			  }    
			}

			
			public static void printAllTeachersOfCathedraSortedByNames() throws IOException{
			    
			    if (University.getFaculties().length != 0) {
			      University.printAllFaculties();
			      boolean foundFaculty = false;
			      String nameF = DataInput.takeInputString("Введіть назву факультета для пошуку кафедри: ");
			      for (Faculty faculty : University.getFaculties()) {
			        if (faculty.getName().equals(nameF)) {
			          if (faculty.getNumberOfCathedras() != 0) {//есть метод Cathedra.teachersPresent( cathedra)
			            if (faculty.getNumberOfTeachersOnFaculty() != 0){//есть метод Faculty.teachersPresent( faculty)
			              printAllCathedras(faculty);
			              boolean foundCathedra = false;
			              String nameC = DataInput.takeInputString("Введіть назву кафедри для виведення викладачів за алфавітом: ");
			              Teacher teachers[] = University.sortTeachersbyNames(faculty.getTeachersOfFaculty(faculty));
			              for (Cathedra cathedra: faculty.getCathedras()){
			                if (cathedra.getName().equals(nameC)) {
			                  if (cathedra.getNumberOfTeachers() != 0){
			                    System.out.println("Список викладачів кафедри " + cathedra.getName() + " за алфавітом: ");
			                    System.out.println();
			                    int numberOfTeaher = 1;
			                    for (Teacher teacher : teachers) {
			                      if (teacher != null){
			                        if (teacher.getCathedra().equals(nameC)){
			                          System.out.println(numberOfTeaher + ". " + teacher .toString());
			                          numberOfTeaher++;
			                        }
			                      }  
			                    }
			                  }
			                  else {
			                    System.out.println();
			                    System.out.println("На кафедру не додано жодного викладача!");
			                  }
			                  foundCathedra = true;
			                  break;
			                }  
			              }
			              if (foundCathedra == false) {
			                System.out.println();
			                System.out.println("Кафедри з такою назвою не знайдено!");
			              }    
			            } else {
			              System.out.println();
			              System.out.println("На факультет не додано жодного викладача!");
			            }
			          }
			          else {
			            System.out.println();
			            System.out.println("На факультеті немає жодної кафедри! Спочатку додайте кафедру!");
			          }  
			          foundFaculty = true;
			          break;
			        }
			      }
			      if (foundFaculty == false) {
			        System.out.println();
			        System.out.println("Факультета з такою назвою не знайдено!");
			      } 
			    }  
			    else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }    
			  }

			
			public static void printAllStudentsSortedByCourses() throws IOException{
			    if (faculties.length != 0) {// University.facultiesPresent()
			    	boolean areStudentsPresent = false;
			    }
			      for (Faculty faculty : getFaculties()) {
			        if (faculty.getNumberOfStudentsOnFaculty() != 0){ //есть метод Faculty.studentsPresent(Faculty faculty)
			          areStudentsPresent = true;
			          break;
			        }
			      }
			      if (areStudentsPresent == true){
			        System.out.println("Список студентів університету впорядкованих за курсами:");
			        for (int i = 1; i <= 6; i++){
			          System.out.println();
			          System.out.println("Студенти " + i + " курсу:");
			          System.out.println();
			          int numberOfStudent = 1;
			          for (Faculty faculty : getFaculties()) {
			            for (Specialty specialty : faculty.getSpecialties()) {
			              for (Course course : specialty.getCourses()) {
			                if (course.getCourse() == i){
			                  for (Group group : course.getGroups()) {
			                    for (Student student : group.getStudents()) {
			                      System.out.println(numberOfStudent + ". " + student.toString());
			                      numberOfStudent ++;
			                    }
			                  }
			                }  
			              }
			            }  
			          }
			        }
			      } else {
			        System.out.println();
			        System.out.println("В університеті немає жодного студента!");
			      }
			    } else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }
			  }
			  
			  public void printAllStudentsOnFaculty() throws IOException{
			    if (faculties.length != 0) {// University.facultiesPresent()
			      printAllFaculties();
			      boolean found = false;
			      String name = DataInput.takeInputString("Введіть назву факультета для виведення всіх студентів за алфавітом: ");
			      for (Faculty faculty : faculties) {
			        if (faculty.getName().equals(name)) {
			          Student students[] = sortStudentsbyNames(Faculty.createArrayOfStudentsOfFaculty(faculty));
			          if (faculty.getNumberOfStudentsOnFaculty() != 0){ //есть метод Faculty.studentsPresent(Faculty faculty)
			            System.out.println("Список студентів факультету " + faculty.getName() + " за алфавітом: ");
			            System.out.println();
			            for (Student s : students) {
			              if (s != null)
			                System.out.println((Arrays.asList(students).indexOf(s) + 1) + ". " + s.toString());
			            }
			          }
			          else {
			            System.out.println();
			            System.out.println("На факультет не додано жодного студента!");
			          }
			          found = true;
			          break;
			        }
			      }
			      if (found == false) {
			        System.out.println();
			        System.out.println("Факультета з такою назвою не знайдено!");
			      }
			    } else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }
			  }
			  
			  
			  
			  public static Student[] sortStudentsbyNames(Student[] students){
			    int length = students.length;
			    Student[] studentsSorted = new Student[length];
			    
			    for (int i = 0; i < length; i++){
			      studentsSorted[i] = students[i];
			      }
			    
			    for (int j = 0; j < length; j++) {
			            for (int i = j + 1; i < length; i++) {
			                if (DataInput.compareTo(studentsSorted[i].getName(), studentsSorted[j].getName()) < 0){  
			                  Student st = new Student("");
			                    st = studentsSorted[j];
			                    studentsSorted[j] = studentsSorted[i];
			                    studentsSorted[i] = st;
			                }
			            }
			        } 
			    return studentsSorted;
			  }
			  
			    public void printAllTeachersOnFaculty() throws IOException{
			    
			    if (faculties.length != 0) {
			      printAllFaculties();
			      boolean found = false;
			      String name = DataInput.takeInputString("Введіть назву факультета для виведення всіх викладачів за алфавітом: ");
			      for (Faculty faculty : faculties) {
			        if (faculty.getName().equals(name)) {
			          Teacher teachers[] = sortTeachersbyNames(getTeachersOfFaculty(faculty));
			          if (faculty.getNumberOfTeachersOnFaculty() != 0){
	
	

//////////////////////////////////////////////////////////////////////////////////////////
	public int getNumberOfStudentsInFaculty() {
		return numberOfStudentsInFaculty;
	}

	public void setNumberOfStudentsInFaculty(int numberOfStudentsInFaculty) {
		this.numberOfStudentsInFaculty = numberOfStudentsInFaculty;
	}

	/**
	 * повертає масив спеціальностей
	 * 
	 * @return
	 */
	public Specialty[] getSpecialties() {
		return specialties;
	}

	/**
	 * встановлює масив спеціальностей
	 * 
	 * @param specialties
	 */
	public void setSpecialties(Specialty[] specialties) {
		this.specialties = specialties;

	}

	/**
	 * повертає назву факультету
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * встановлює назву факультету
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * повертає кількість факультетів
	 * 
	 * @return
	 */
	public static int getNumberOfFaculties() {
		return numberOfFaculties;
	}

	/**
	 * встановлює кількість факультетів
	 * 
	 * @param numberOfFaculties
	 */
	public static void setNumberOfFaculties(int numberOfFaculties) {
		Faculty.numberOfFaculties = numberOfFaculties;
	}

	/**
	 * повертає кількість спеціальностей факульетета
	 * 
	 * @return
	 */
	public int getNumberOfSpecialties() {
		return numberOfSpecialties;
	}

	/**
	 * встановлює кількість спеціальностей факультету
	 * 
	 * @param numberOfSpecialties
	 */
	public void setNumberOfSpecialties(int numberOfSpecialties) {
		this.numberOfSpecialties = numberOfSpecialties;
	}

	/**
	 * повертає масив кафедр
	 * 
	 * @return
	 */
	public Cathedra[] getCathedras() {
		return cathedras;
	}

	/**
	 * встановлює масив кафедр
	 * 
	 * @param cathedras
	 */
	public void setCathedras(Cathedra[] cathedras) {
		this.cathedras = cathedras;
	}

	/**
	 * повертає кількість кафедр
	 * 
	 * @return
	 */
	public int getNumberOfCathedras() {
		return numberOfCathedras;
	}

	/**
	 * встановлює кількість кафедр
	 * 
	 * @param numberOfCathedras
	 */
	public void setNumberOfCathedras(int numberOfCathedras) {
		this.numberOfCathedras = numberOfCathedras;
	}

}

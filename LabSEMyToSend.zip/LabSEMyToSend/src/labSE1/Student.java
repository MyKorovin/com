package labSE1;

import java.io.IOException;
import java.util.Arrays;

public class Student {

	private String name;
	private String faculty;
	private String specialty;
	private int course;
	private int group;

	public boolean equals(Student student) {
		return (name.equals(student.getName())&&faculty.equals(student.getFaculty())&&specialty.equals(student.getSpecialty())&& course == student.getCourse() && group == student.getGroup());
	}
	
	
	
	
	
	
	
	/**
	 * конструктор без параметрів, що встановлює ім'я та прізвище студента
	 * 
	 * @throws IOException
	 */
	public Student() throws IOException {
		System.out.println();
		this.name = DataInput.takeInputString("Введіть прізвище та ім'я студента: ");
	}
	
	public Student(Group group) {
		
	}

	/**
	 * конструктор, що встановлює ім'я та прізвище студента
	 * 
	 * @param name
	 */
	public Student(String name) {
		this.name = name;
	}

	/**
	 * певертає ім'я та прізвище студента
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * встановлює ім'я та прізвище студента
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * повертає назву факультета, на якому навчається студент
	 * 
	 * @return
	 */
	public String getFaculty() {
		return faculty;
	}

	/**
	 * встановлює назву факультета
	 * 
	 * @param faculty
	 */
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	/**
	 * повертає назву спеціальності
	 * 
	 * @return
	 */
	public String getSpecialty() {
		return specialty;
	}

	/**
	 * встановлює назву спеціальності
	 * 
	 * @param specialty
	 */
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	/**
	 * повертає номер курсу
	 * 
	 * @return
	 */
	public int getCourse() {
		return course;
	}

	/**
	 * встановлює номер курсу
	 * 
	 * @param course
	 */
	public void setCourse(int course) {
		this.course = course;
	}

	/**
	 * повертає номер групи
	 * 
	 * @return
	 */
	public int getGroup() {
		return group;
	}

	/**
	 * встановлює номер групи
	 * 
	 * @param group
	 */
	public void setGroup(int group) {
		this.group = group;
	}

	// Student to String??????????????????
	public String toString() {
		return name + " навчається на факультеті " + faculty + " на спеціальності "
				+ specialty + " на " + course + " курсі у " +group + " групі";

	}

}

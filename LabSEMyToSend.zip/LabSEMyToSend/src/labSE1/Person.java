package labSE1;

import java.io.IOException;

public class Person {

	public String name = "";
	
	
	public Person(String name) {
		this.name= name;
	}
	
	public Person() throws IOException {
		String name = DataInput.getString();
		while (name.length() == 0 || checkName(name) == false) {
			name = DataInput.getString();
		}
		this.name = name;
	}
	
	
	
	
	/**
	 * Перевіряє ім'я та прізвище на відсутність зайвих знаків
	 * 
	 * @param name
	 * @return
	 */
	private boolean checkName(String name) {
		for (int i = 0; i < name.length(); i++) {
			if ((name.charAt(i) > ' ' && name.charAt(i) < '\'') || (name.charAt(i) > '-' && name.charAt(i) <= '@')
					|| (name.charAt(i) >= '[' && name.charAt(i) <= '`')
					|| (name.charAt(i) >= '{' && name.charAt(i) <= '~')) {
				return false;
			}
		}
		return true;
	}
}

package labSE1;

public class Course {

	private Group[] groups = new Group[6];

	private int course;
	private Specialty specialty;

	private int numberOfStudentsOnCourse = 0;

	public int getNumberOfStudentsOnCourse() {
		return numberOfStudentsOnCourse;
	}

	public void setNumberOfStudentsOnCourse(int numberOfStudentsOnCourse) {
		this.numberOfStudentsOnCourse = numberOfStudentsOnCourse;
	}

	/**
	 * конструктор, що задає номер курсу та додає до курсу групи
	 * 
	 * @param course
	 */
	public Course(int course, Specialty specialty) {
		this.course = course;
		this.specialty = specialty;
		addGroups();
	}

	public Specialty getSpecialty() {
		return specialty;
	}

	public void setSpecialty(Specialty specialty) {
		this.specialty = specialty;
	}

	/**
	 * додає 6 груп
	 */
	private void addGroups() {
		for (int i = 0; i < 6; i++) {
			groups[i] = new Group(i + 1, this);
		}
	}

	/**перевіряє, чи є на курсі студенти
	 * @param course
	 * @return
	 */
	public static boolean studentsPresent(Course course) {
		int num = 0;
		for (Group group : course.getGroups()) {
			num += group.getNumberOfStudents();
		}

		if (num != 0) {
			return true;
		}
		System.out.println();
		System.out.println("Не додано жодного студента!");
		return false;
	}

	/**
	 * повертає масив груп
	 * 
	 * @return
	 */
	public Group[] getGroups() {
		return groups;
	}

	/**
	 * встановлює групи
	 * 
	 * @param groups
	 */
	public void setGroups(Group[] groups) {
		this.groups = groups;
	}

	/**
	 * повертає номер курсу
	 * 
	 * @return
	 */
	public int getCourse() {
		return course;
	}

	/**
	 * встановлює курс
	 * 
	 * @param course
	 */
	public void setCourse(int course) {
		this.course = course;
	}

}

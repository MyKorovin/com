package labSE1;
import java.io.IOException;

import labSE1.DataInput;

public class Tester {
  
  public static void main(String[] args) throws IOException {
    Tester tester = new Tester();
    University university = new University();
    tester.menu(university);  
  }  
  
  public void menu(University university) throws IOException {
    System.out.println("Формування списку студентів та викладачів університету");
    int stop = -1;
    while (stop != 0){
      System.out.println("Головне меню. Оберіть, з чим хочете працювати");
      System.out.println("0)Закінчити роботу");
      System.out.println("1)Факультет");
      System.out.println("2)Кафедра");
      System.out.println("3)Спеціальність");
      System.out.println("4)Курс");
      System.out.println("5)Студент");
      System.out.println("6)Викладач");
      int choice = -1;
      while ((choice != 0)&&(choice != 1)&&(choice != 2)&&(choice != 3)&&(choice != 4)&&(choice != 5)&&(choice != 6)){
        System.out.println("Вибір(0-5)?");
        choice = DataInput.getInt("");
        switch(choice){
        case 0:
          System.out.println("Ви закінчили роботу з програмою");
          stop = 0;
          break;
        case 1:
          System.out.println();
          workWithFaculty(university);
          break;
          case 2:
            System.out.println();
          workWithCathedra();
            break;
          case 3:
            System.out.println();
            workWithSpecialty();
            break;
          case 4:
            System.out.println();
            workWithCourse();
            break;  
          case 5:
            System.out.println();
            workWithStudent();
            break;
          case 6:
            System.out.println();
            workWithTeacher();
            break;
          default:
            System.out.println("Помилка!");
            break;
        }
      }
      System.out.println("");  
    }
  }
  
  public void workWithFaculty(University university) throws IOException {
    int stopFaculty = -1;
    while (stopFaculty != 0){
      System.out.println("Факультет");
      System.out.println("Меню. Оберіть, з чим хочете працювати");
      System.out.println("0)Повернутися до головного меню");
      System.out.println("1)Створити новий факультет");
      System.out.println("2)Редагувати факультет");
      System.out.println("3)Видалити факультет");
      System.out.println("4)Вивести всіх студентів факультету впорядкованих за алфавітом");
      System.out.println("5)Вивести всіх викладачів факультету впорядкованих за алфавітом");
      int choiceInFaculty = -1;
      while ((choiceInFaculty != 0)&&(choiceInFaculty != 1)&&(choiceInFaculty != 2)&&(choiceInFaculty != 3)&&(choiceInFaculty != 4)&&(choiceInFaculty != 5)){
        System.out.println("Вибір(0-5)?");
        choiceInFaculty = DataInput.getInt("");
        switch(choiceInFaculty){
        case 0:
          System.out.println("Ви перейшли в головне меню");
          stopFaculty = 0;
          break;
        case 1:
          System.out.println();
          university.addFaculty();
          System.out.println();
          break;
        case 2:
          System.out.println();
          university.changeNameOfFaculty();
          System.out.println();
          break;
        case 3:
          System.out.println();
          university.deleteFaculty();
          System.out.println();
          break;
          case 4:
            System.out.println();
            university.printAllStudentsOnFaculty();
            System.out.println();
            break;
          case 5:
            System.out.println();
            university.printAllTeachersOnFaculty();
            System.out.println();
            break;
          default:
            System.out.println("Помилка!");
            break;  
        }
      }  
    }  
  }
  
  
  public void workWithCathedra() throws IOException {
    int stopCathedra = -1;
    while (stopCathedra != 0){
      System.out.println("Кафедра");
        System.out.println("Меню. Оберіть, з чим хочете працювати");
        System.out.println("0)Повернутися до головного меню");
        System.out.println("1)Створити нову кафедру");
        System.out.println("2)Редагувати кафедру");
        System.out.println("3)Видалити кафедру");
        System.out.println("4)Вивести всіх викладачів кафедри впорядкованих за алфавітом");
        int choiceInCathedra = -1;
        while ((choiceInCathedra != 0)&&(choiceInCathedra != 1)&&(choiceInCathedra != 2)&&(choiceInCathedra != 3)&&(choiceInCathedra != 4)){
          System.out.println("Вибір(0-4)?");
          choiceInCathedra = DataInput.getInt("");
          switch(choiceInCathedra){
          case 0:
            System.out.println("Ви перейшли в головне меню");
            stopCathedra = 0;
            break;
          case 1:
            System.out.println();
            Faculty.askForFacultyCathedra("Введіть назву факультета, на який потрібно додати кафедри: ");
            System.out.println();
            break;
          case 2:
            System.out.println();
            Faculty.askForFacultyToRenameCathedra("Введіть назву факультета, у якому потрібно змінити кафедру: ");
            System.out.println();
            break;
          case 3:
            System.out.println();
            Faculty.askForFacultyToDeleteCathedra("Введіть назву факультета, з якого потрібно видалити кафедру: ");
            System.out.println();
            break;
            case 4:
              Faculty.printAllTeachersOfCathedraSortedByNames();
              break;
            default:
              System.out.println("Помилка!");
              break;  
          }
        }  
      }  
    }
    
      public void workWithSpecialty() throws IOException {
        int stopSpecialty = -1;
      while (stopSpecialty != 0){
        System.out.println("Спеціальність");
          System.out.println("Меню. Оберіть, з чим хочете працювати");
        System.out.println("0)Повернутися до головного меню");
        System.out.println("1)Створити нову спеціальність");
        System.out.println("2)Редагувати спеціальність");
        System.out.println("3)Видалити спеціальність");
        System.out.println("4)Вивести всіх студентів спеціальності впорядкованих за алфавітом");
        System.out.println("5)Вивести всіх студентів спеціальності впорядкованих за курсами");
        int choiceInSpecialty = -1;
        while ((choiceInSpecialty != 0)&&(choiceInSpecialty != 1)&&(choiceInSpecialty != 2)&&(choiceInSpecialty != 3)&&(choiceInSpecialty != 4)&&(choiceInSpecialty != 5)){
          System.out.println("Вибір(0-5)?");
          choiceInSpecialty = DataInput.getInt("");
          switch(choiceInSpecialty){
          case 0:
            System.out.println("Ви перейшли в головне меню");
            stopSpecialty = 0;
            break;
          case 1:
            System.out.println();
            Faculty.askForFaculty("Введіть назву факультета, на який потрібно додати спеціальності: ");
            System.out.println();
            break;
          case 2:
            System.out.println();
            Faculty.askForFacultyToRename("Введіть назву факультета, у якому потрібно змінити спеціальність: ");
            System.out.println();
            break;
          case 3:
            System.out.println();
            Faculty.askForFacultyToDelete("Введіть назву факультета, з якого потрібно видалити спеціальність: ");
            System.out.println();
            break;
            case 4:
              System.out.println();
              Faculty.printAllStudentsOfSpecialtySortedByNames();
              System.out.println();
              break;
            case 5:
              System.out.println();
              Faculty.printAllStudentsOfSpecialtySortedByCourses();
              System.out.println();
              break;
            default:
              System.out.println("Помилка!");
              break;  
          }
        }    
      }
    }
      
      public void workWithCourse() throws IOException {
        int stopCourse = -1;
      while (stopCourse != 0){
        System.out.println("Курс");
          System.out.println("Меню. Оберіть, з чим хочете працювати");
          System.out.println("0)Повернутися до головного меню");
          System.out.println("1)Вивести всіх студентів впорядкованих за курсами");
          System.out.println("2)Вивести всіх студентів спеціальності вказаного курсу");
          System.out.println("3)Вивести всіх студентів спеціальності вказаного курсу впорядкованих за алфавітом");
          int choiceInCourse = -1;
          while ((choiceInCourse != 0)&&(choiceInCourse != 1)&&(choiceInCourse != 2)&&(choiceInCourse != 3)){
            System.out.println("Вибір(0-3)?");
            choiceInCourse = DataInput.getInt("");
            switch(choiceInCourse){
            case 0:
              System.out.println("Ви перейшли в головне меню");
              stopCourse = 0;
              break;
            case 1:
              System.out.println();
              University.printAllStudentsSortedByCourses();
              System.out.println();
              break;  
            case 2:
                System.out.println();
                Faculty.printAllStudentsOfSpecialtyOfNeededCourse();
                System.out.println();
                break;
              case 3:
                System.out.println();
                Faculty.printAllStudentsOfSpecialtyOfNeededCourseSortedByNames();
                System.out.println();
                break;
              default:
                System.out.println("Помилка!");
                break;  
            }
          }  
        }
      }
      
      public void workWithStudent() throws IOException {
        int stopStudent = -1;
        while (stopStudent != 0){
          System.out.println("Студент");
            System.out.println("Меню. Оберіть, з чим хочете працювати");
            System.out.println("0)Повернутися до головного меню");
          System.out.println("1)Додати нового студента");
          System.out.println("2)Редагувати ПІБ студента");
          System.out.println("3)Перемістити студента");
          System.out.println("4)Видалити студента");
          System.out.println("5)Знайти студента за ПІБ");
          System.out.println("6)Знайти студента за курсом");
          System.out.println("7)Знайти студента за групою");
          int choiceInStudent = -1;
          while ((choiceInStudent != 0)&&(choiceInStudent != 1)&&(choiceInStudent != 2)&&(choiceInStudent != 3)&&(choiceInStudent != 4)&&(choiceInStudent != 5)&&(choiceInStudent != 6)&&(choiceInStudent != 7)){
            System.out.println("Вибір(0-7)?");
            choiceInStudent = DataInput.getInt("");
            switch(choiceInStudent){
            case 0:
              System.out.println("Ви перейшли в головне меню");
              stopStudent = 0;
              break;
            case 1:
              System.out.println();
              Group.addStudent();
              System.out.println();
              break;
            case 2:
              System.out.println();
              Group.changeStudent();
              System.out.println();
              break;
            case 3:
              System.out.println();
              Group.replaceStudent();
              System.out.println();
              break;  
              case 4:
                System.out.println();
              Group.deleteStudent();
              System.out.println();
              break;
              case 5:
                System.out.println();
                //Group.findStudentWithName();
                System.out.println();
                break;
              case 6:
                System.out.println("Введіть курс студента для пошуку: ");
                break;
              case 7:
                System.out.println("Введіть групу студента для пошуку: ");
                break;  
              default:
                System.out.println("Помилка!");
                break;  
            }
          }  
        }
      }
      
      public void workWithTeacher() throws IOException {
        int stopTeacher = -1;
        while (stopTeacher != 0){
          System.out.println("Викладач");
            System.out.println("Меню. Оберіть, з чим хочете працювати");
            System.out.println("0)Повернутися до головного меню");
          System.out.println("1)Додати нового викладача");
          System.out.println("2)Редагувати ПІБ викладача");
          System.out.println("3)Перемістити викладача");
          System.out.println("4)Видалити викладача");
          System.out.println("5)Знайти викладача за ПІБ");
          int choiceInTeacher = -1;
          while ((choiceInTeacher != 0)&&(choiceInTeacher != 1)&&(choiceInTeacher != 2)&&(choiceInTeacher != 3)&&(choiceInTeacher != 4)&&(choiceInTeacher != 5)){
              System.out.println("Вибір(0-6)?");
              choiceInTeacher = DataInput.getInt("");
              switch(choiceInTeacher){
              case 0:
                System.out.println("Ви перейшли в головне меню");
                stopTeacher = 0;
                break;
              case 1:
                System.out.println();
                Cathedra.addTeacher();
                System.out.println();
                break;  
              case 2:
                System.out.println();
                Cathedra.changeTeacher();
                System.out.println();
                break;
              case 3:
                System.out.println();
                Cathedra.replaceTeacher();
                System.out.println();
                break;  
                case 4:
                  System.out.println();
                Cathedra.deleteTeacher();
                System.out.println();
                break;
                case 5:
                  System.out.println();
                  //Cathedra.findTeacherWithName();
                  System.out.println();
                  break;
                case 6:
    				System.out.println();
    				Cathedra.addSubjects();
    				System.out.println();
    				break;
                default:
                  System.out.println("Помилка!");
                  break;  
              }
            }
          }
        }
      }
        
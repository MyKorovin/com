package labSE1;

import java.io.IOException;
import java.util.Arrays;

/**
 * @author illia_sitkov
 *
 */
public class Group {

	

	private Student[] students = new Student[0];
	private int numberOfStudents = 0;

	
	
	private int numberOfTeachersInGroup = 0;
	private Teacher[] teachers = new Teacher[0];
	
	
	
	
	
	private int group;
	private Course course;

	/**
	 * конструктор без параметрів, що встановлює номер групи
	 * 
	 * @param group
	 */
	public Group(int group, Course course) {
		this.group = group;
		this.course = course;
	}

	/*
	 * public boolean equals(Group group) { if (group != null && this != null) { int
	 * g = this.group; int g2 = group.getGroup(); int c = this.course; int c2 =
	 * group.getCourse(); return (this.group == group.getGroup() && this.course ==
	 * group.getCourse()); } return false; }
	 */
	/**перевіряє, чи є в групі студенти
	 * @param group
	 * @return
	 */
	public static boolean studentsPresent(Group group) {
		if (group.getNumberOfStudents() != 0) {
			return true;
		}
		System.out.println();
		System.out.println("Не додано жодного студента!");
		return false;
	}

	/**
	 * запитує всі дані для додавання студента
	 * 
	 * @throws IOException
	 */
	public static void addStudent() throws IOException {
		if (University.facultiesPresent() && University.specialtiesPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, на який потрібно додати студента: ");
			if (faculty != null && Faculty.specialtiesPresent(faculty)) {
				Specialty specialty = askForSpecialty(faculty,
						"Введіть спеціальність, на яку потрібно додати студента: ");
				if (specialty != null) {
					Course course = askForCourse(specialty, "Введіть курс (1 - 6), на який потрібно додати студента: ");
					Group group = askForGroup(course, "Введіть номер групи (1 - 6), у яку потрібно додати студента: ");
					addStudent(group, course, specialty, faculty);
				}
			}
		}
	}

	/**
	 * запитує всі дані для видалення студента
	 * 
	 * @throws IOException
	 */
	public static void deleteStudent() throws IOException {
		if (University.facultiesPresent() && University.specialtiesPresent() && University.studentsPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, з якого треба видалити студента: ");
			if (faculty != null && Faculty.specialtiesPresent(faculty) && Faculty.studentsPresent(faculty)) {
				Specialty specialty = askForSpecialty(faculty,
						"Введіть спеціальність, з якої треба видалити студента: ");
				if (specialty != null && Specialty.studentsPresent(specialty)) {
					Course course = askForCourse(specialty, "Введіть курс (1 - 6), з якого треба видалити студента: ");
					if (Course.studentsPresent(course)) {
						Group group = askForGroup(course,
								"Введіть номер групи (1 - 6), з якої треба видалити студента: ");
						if (studentsPresent(group)) {
							deleteStudent(group);
						}
					}
				}
			}
		}
	}

	/**змінює ПІБ студента
	 * @throws IOException
	 */
	public static void changeStudent() throws IOException {
		if (University.facultiesPresent() && University.specialtiesPresent() && University.studentsPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, на якому потрібно змінити студента: ");
			if (faculty != null && Faculty.specialtiesPresent(faculty) && Faculty.studentsPresent(faculty)) {
				Specialty specialty = askForSpecialty(faculty,
						"Введіть спеціальність, на якій потрібно змінити студента: ");
				if (specialty != null && Specialty.studentsPresent(specialty)) {
					Course course = askForCourse(specialty,
							"Введіть курс (1 - 6), на якому потрібно змінити студента: ");
					if (Course.studentsPresent(course)) {
						Group group = askForGroup(course,
								"Введіть номер групи (1 - 6), у якій потрібно змінити студента: ");
						if (studentsPresent(group)) {
							changeStudent(group);
						}
					}
				}
			}
		}
	}

	/**переміщує студента
	 * @throws IOException
	 */
	public static void replaceStudent() throws IOException {
		if (University.facultiesPresent() && University.specialtiesPresent() && University.studentsPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, з якого треба перемістити студента: ");
			if (faculty != null && Faculty.specialtiesPresent(faculty) && Faculty.studentsPresent(faculty)) {
				Specialty specialty = askForSpecialty(faculty,
						"Введіть спеціальність, з якрї треба перемістити студента: ");
				if (specialty != null && Specialty.studentsPresent(specialty)) {
					Course course = askForCourse(specialty,
							"Введіть курс (1 - 6), з якого треба перемістити студента: ");
					if (Course.studentsPresent(course)) {
						Group group = askForGroup(course,
								"Введіть номер групи (1 - 6), з якої треба перемістити студента: ");
						if (studentsPresent(group)) {
							printAllStudents(group);
							String name = DataInput
									.takeInputString("Введіть ім'я та прізвище студента, якого треба перемістити: ");
							Student student = findStudentInGroup(group, name);
							if (student != null) {
								replaceStudent(student);
							}
						}
					}
				}
			}
		}
	}

	/**шукає студента в групі
	 * @param group
	 * @param name
	 * @return
	 */
	private static Student findStudentInGroup(Group group, String name) {
		for (Student student : group.getStudents()) {
			if (student.getName().equals(name)) {
				return student;
			}
		}
		System.out.println();
		System.out.println("Студента з таким ім'ям та прізвищем не знайдено!");
		return null;
	}

	/**переміщує студента
	 * @param student
	 * @throws IOException
	 */
	private static void replaceStudent(Student student) throws IOException {
		Faculty faculty = askForFaculty("Введіть назву факультету, на який треба перемістити студента: ");
		if (faculty != null && Faculty.specialtiesPresent(faculty)) {
			Specialty specialty = askForSpecialty(faculty,
					"Введіть спеціальність, на яку потрібно перемістити студента: ");
			if (specialty != null) {
				Course course = askForCourse(specialty,
						"Введіть курс (1 - 6), на який потрібно перемістити студента: ");
				Group group = askForGroup(course, "Введіть номер групи (1 - 6), у яку потрібно перемістити студента: ");
				replaceStudent(student, faculty, specialty, course, group);
			}
		}
	}

	/**
	 * переміщує студента в конкретну групу курсу спеціальності факультету
	 * 
	 * @param student
	 * @param faculty
	 * @param specialty
	 * @param course
	 * @param group
	 */
	private static void replaceStudent(Student student, Faculty faculty, Specialty specialty, Course course,
			Group group) {
		boolean needsReplace = true;
		if (student.getFaculty().equals(faculty.getName())) {
			if (student.getSpecialty().equals(specialty.getName())) {
				if (student.getCourse() == course.getCourse()) {
					if (student.getGroup() == group.getGroup()) {
						System.out.println();
						System.out.println("Студент вже знаходиться тут");
						needsReplace = false;
					}
				}
			}
		}
		if (needsReplace == true) {
			Student temp = student;
			deleteFound(student);
			addOneStudent(temp, faculty, specialty, course, group);
		}
	}

	/**видаляє студента зі старої групи
	 * @param student
	 */
	private static void deleteFound(Student student) {
		for (Faculty faculty : University.getFaculties()) {
			for (Specialty specialty : faculty.getSpecialties()) {
				for (Course course : specialty.getCourses()) {
					for (Group group : course.getGroups()) {
						for (Student studentOld : group.getStudents()) {
							if (student.equals(studentOld)) {
								Student[] students = group.getStudents();
								students[Arrays.asList(students).indexOf(studentOld)] = null;
								group.setStudents(resortStudents(students));
								group.setNumberOfStudents(group.getNumberOfStudents() - 1);
								break;
							}
						}

					}
				}

			}
		}
	}

	/**
	 * додає одного студента в групу
	 * 
	 * @param student
	 * @param faculty
	 * @param specialty
	 * @param course
	 * @param group
	 */
	private static void addOneStudent(Student student, Faculty faculty, Specialty specialty, Course course,
			Group group) {
		Student[] temp = group.getStudents();
		Student[] students = new Student[group.getNumberOfStudents() + 1];
		students[group.getNumberOfStudents()] = new Student(group);
		students[group.getNumberOfStudents()].setName(student.getName());
		students[group.getNumberOfStudents()].setGroup(group.getGroup());
		students[group.getNumberOfStudents()].setCourse(course.getCourse());
		students[group.getNumberOfStudents()].setSpecialty(specialty.getName());
		students[group.getNumberOfStudents()].setFaculty(faculty.getName());
		group.setNumberOfStudents(group.getNumberOfStudents() + 1);
		for (int i = 0; i < temp.length; i++) {
			students[i] = temp[i];
		}
		group.setStudents(students);
	}

	/**
	 * запитує всі дані для зміни студента
	 * 
	 * @throws IOException
	 */
	/*
	 * public static void changeStudent1() throws IOException { Faculty faculty =
	 * askForFaculty("Введіть назву факультету, на якому потрібно змінити студента: "
	 * ); if (faculty == null && Faculty.numberOfFaculties == 0) {
	 * System.out.println(); System.out.
	 * println("Не додано жодного факультету! Спочатку додайте факультет!"); } else
	 * { Specialty specialty = askForSpecialty(faculty,
	 * "Введіть спеціальність, на якій потрібно змінити студента: "); if (specialty
	 * == null && faculty == null) { System.out.println();
	 * System.out.println("факультету з такою назвою не знайдено!"); } else if
	 * (specialty == null && faculty.getNumberOfSpecialties() == 0) {
	 * System.out.println(); System.out.
	 * println("Не додано жодної спеціальності! Спочатку додайте спеціальність!"); }
	 * else if (specialty == null) { System.out.println();
	 * System.out.println("Спеціальності з такою назвою не знайдено!"); } else {
	 * Course course = askForCourse(specialty,
	 * "Введіть курс (1 - 6), на якому потрібно змінити студента: "); Group group =
	 * askForGroup(course,
	 * "Введіть номер групи (1 - 6), у якій потрібно змінити студента: ");
	 * changeStudent(group); } } }
	 */
	/**
	 * запитує, на який факультет додавати студента
	 * 
	 * @param prompt
	 * @return
	 * @throws IOException
	 */
	private static Faculty askForFaculty(String prompt) throws IOException {
		University.printAllFaculties();
		Faculty neededFaculty = null;
		String name = DataInput.takeInputString(prompt);
		Faculty[] faculties = University.getFaculties();
		for (Faculty faculty : faculties) {
			if (faculty.getName().equals(name)) {
				neededFaculty = faculty;
				return neededFaculty;
			}
		}
		if (neededFaculty == null) {
			System.out.println();
			System.out.println("Факультету з такою назвою не знайдено!");
		}
		return null;
	}

	/**
	 * запитує, на яку спеціальність треба додавати студента
	 * 
	 * @param neededFaculty
	 * @param prompt
	 * @return
	 * @throws IOException
	 */
	public static Specialty askForSpecialty(Faculty neededFaculty, String prompt) throws IOException {
		Faculty.printAllSpecialties(neededFaculty);
		Specialty neededSpecialty = null;
		String name = DataInput.takeInputString(prompt);
		Specialty[] specialties = neededFaculty.getSpecialties();
		for (Specialty specialty : specialties) {
			if (specialty.getName().equals(name)) {
				neededSpecialty = specialty;
				return neededSpecialty;
			}
		}
		if (neededSpecialty == null) {
			System.out.println();
			System.out.println("Спеціальності з такою назвою не знайдено!");
		}
		return null;
	}

	/**
	 * запитує користувача, на який курс додавати студента
	 * 
	 * @param neededSpecialty
	 * @param prompt
	 * @return
	 * @throws IOException
	 */
	public static Course askForCourse(Specialty neededSpecialty, String prompt) throws IOException {
		int number = DataInput.getInt(prompt);
		while (number < 1 || number > 6) {
			number = DataInput.getInt("Помилка! " + prompt);
		}
		Course neededCourse = neededSpecialty.getCourses()[number - 1];
		return neededCourse;
	}

	/**
	 * запитує користувача, у яку групу додавати студента
	 * 
	 * @param neededCourse
	 * @param prompt
	 * @return
	 * @throws IOException
	 */
	public static Group askForGroup(Course neededCourse, String prompt) throws IOException {
		int number = DataInput.getInt(prompt);
		while (number < 1 || number > 6) {
			number = DataInput.getInt("Помилка! " + prompt);
		}
		Group neededGroup = neededCourse.getGroups()[number - 1];
		return neededGroup;

	}

	/**
	 * додає студента до необхідних групи, курсу, спеціальності. факультету
	 * 
	 * @param neededGroup
	 * @param course
	 * @param specialty
	 * @param faculty
	 * @throws IOException
	 */
	private static void addStudent(Group neededGroup, Course course, Specialty specialty, Faculty faculty)
			throws IOException {
		Student[] students = neededGroup.getStudents();
		printAllStudents(neededGroup);
		while (true) {
			Student[] temp = students;
			students = new Student[temp.length + 1];
			students[neededGroup.getNumberOfStudents()] = new Student();
			students[neededGroup.getNumberOfStudents()].setGroup(neededGroup.getGroup());
			students[neededGroup.getNumberOfStudents()].setCourse(course.getCourse());
			students[neededGroup.getNumberOfStudents()].setSpecialty(specialty.getName());
			students[neededGroup.getNumberOfStudents()].setFaculty(faculty.getName());
			neededGroup.setNumberOfStudents(neededGroup.getNumberOfStudents() + 1);
			for (int i = 0; i < temp.length; i++) {
				students[i] = temp[i];
			}
			String prod = DataInput.takeInputString("Продовжити введення? так/ні ");
			if (prod.charAt(0) == 'н')
				break;
		}
		neededGroup.setStudents(students);
		printAllStudents(neededGroup);
	}

	/**
	 * видаляє студента з групи
	 * 
	 * @param group
	 * @throws IOException
	 */
	private static void deleteStudent(Group group) throws IOException {
		printAllStudents(group);
		Student[] students = group.getStudents();
		boolean found = false;
		String name = DataInput.takeInputString("Введіть ім'я та прізвище студента, якого потрібно видалити: ");
		for (Student student : students) {
			if (student.getName().equals(name)) {
				students[Arrays.asList(students).indexOf(student)] = null;
				group.setStudents(resortStudents(students));
				found = true;
				group.setNumberOfStudents(group.getNumberOfStudents() - 1);
				printAllStudents(group);
				break;
			}
		}
		if (found == false) {
			System.out.println();
			System.out.println("Студента з таким ім'ям та прізвищем не знайдено!");
		}
	}

	/**
	 * змінює ім'я та прізвище студента
	 * 
	 * @param group
	 * @throws IOException
	 */
	private static void changeStudent(Group group) throws IOException {
		Student[] students = group.getStudents();
		printAllStudents(group);
		boolean found = false;
		String name = DataInput.takeInputString("Введіть ім'я та прізвище студента, якого потрібно змінити: ");
		for (Student student : students) {
			if (student.getName().equals(name)) {
				String newName = DataInput.takeInputString("Введіть нові ім'я та прізвище студента: ");
				student.setName(newName);
				found = true;
				printAllStudents(group);
				break;
			}
		}
		if (found == false) {
			System.out.println();
			System.out.println("Студента з таким ім'ям та прізвищем не знайдено!");
		}
	}

	/**
	 * сортує студентів після видалення
	 * 
	 * @param students
	 * @return
	 */
	private static Student[] resortStudents(Student[] students) {
		Student[] temp = students;
		students = new Student[0];
		for (int i = 0, j = 0; i < temp.length; i++) {
			if (temp[i] != null) {
				Student[] temp1 = students;
				students = new Student[students.length + 1];
				students[j] = temp[i];
				for (int k = 0; k < temp1.length; k++) {
					students[k] = temp1[k];
				}
				j++;
			}
		}
		return students;
	}

	/**
	 * друкує всіх студентів групи без додаткової інформації
	 * 
	 * @param group
	 */
	public static void printAllStudentsShort(Group group) {
		Student[] students = group.getStudents();
		System.out.println();
		System.out.println("Список студентів групи " + group.getGroup() + ": ");
		for (Student student : students) {
			if (students != null)
				System.out.println((Arrays.asList(students).indexOf(student) + 1) + ". " + student.getName());
		}
		if (students.length == 0) {
			System.out.println();
			System.out.println("Не додано жодного студента");
		}

	}

	/**
	 * друкує всіх студентів групи з додатковою інформацією
	 * 
	 * @param group
	 */
	public static void printAllStudents(Group group) {
		Student[] students = group.getStudents();
		System.out.println();
		System.out.println("Список студентів групи " + group.getGroup() + ": ");
		for (Student student : students) {
			if (students != null)
				System.out.println((Arrays.asList(students).indexOf(student) + 1) + ". " + student.toString());
		}
		if (students.length == 0) {
			System.out.println();
			System.out.println("Не додано жодного студента");
		}
	}

	/**
	 * шукає студента із заданим ім'ям та прізвищем
	 * 
	 * @param name
	 * @return
	 * @throws IOException
	 */
	private static Student findStudent(String name) throws IOException {
		for (Faculty faculty : University.getFaculties()) {
			for (Specialty specialty : faculty.getSpecialties()) {
				for (Course course : specialty.getCourses()) {
					for (Group group : course.getGroups()) {
						for (Student student : group.getStudents()) {
							if (student.getName().equals(name)) {
								return student;
							}
						}
					}
				}
			}
		}
		System.out.println();
		System.out.println("Студента з таким ім'ям та прізвищем не було знайдено!");
		return null;
	}

	/**
	 * видаляє студента із заданими ім'ям та прізвищем
	 * 
	 * @param name
	 */
	/*
	 * private static void deleteFound(Student student) { for (Faculty faculty :
	 * University.getFaculties()) { for (Specialty specialty :
	 * faculty.getSpecialties()) { for (Course course : specialty.getCourses()) {
	 * for (Group group : course.getGroups()) { for (Student student :
	 * group.getStudents()) { if (student.getName().equals(name)) { Student[]
	 * students = group.getStudents();
	 * students[Arrays.asList(students).indexOf(student)] = null;
	 * group.setStudents(resortStudents(students));
	 * group.setNumberOfStudents(group.getNumberOfStudents() - 1); break; } } } } }
	 * } }
	 */

	/**
	 * знаходить усіх студентів, які мають задане ім'я
	 * 
	 * @throws IOException
	 */
	public static void findStudentByName() throws IOException {
		String name = DataInput.takeInputString("Введіть ім'я та прізвище студента, якого треба знайти: ");
		Student[] foundStudents = findStudent1(name);
		if (foundStudents != null)
			printAllFoundStudents(foundStudents);
	}

	/**
	 * повертає масив студентів, які мають задане ім'я
	 * 
	 * @param name
	 * @return
	 * @throws IOException
	 */
	private static Student[] findStudent1(String name) throws IOException {
		Student[] students = new Student[0];
		boolean isFound = false;
		for (Faculty faculty : University.getFaculties()) {
			for (Specialty specialty : faculty.getSpecialties()) {
				for (Course course : specialty.getCourses()) {
					for (Group group : course.getGroups()) {
						for (Student student : group.getStudents()) {
							if (student.getName().equals(name)) {
								Student[] temp = students;
								students = new Student[students.length + 1];
								students[temp.length] = student;
								for (int i = 0; i < temp.length; i++) {
									students[i] = temp[i];
								}
								isFound = true;
							}
						}
					}
				}
			}
		}
		if (isFound == false) {
			System.out.println();
			System.out.println("Студента з таким ім'ям та прізвищем не було знайдено!");
			return null;
		}
		return students;
	}

	/**
	 * друкує усіх знайдених за ім'ям студентів
	 * 
	 * @param students
	 */
	private static void printAllFoundStudents(Student[] students) {
		System.out.println();
		System.out.println("Список студентів із вказаними ім'ям та прізвищем: ");
		for (Student student : students) {
			if (student != null) {
				System.out.println((Arrays.asList(students).indexOf(student) + 1) + ". " + student.getName()
						+ " навчається на факультеті " + student.getFaculty() + " на спеціальності "
						+ student.getSpecialty() + " на " + student.getCourse() + " курсі у " + student.getGroup()
						+ " групі");
			}
		}
		if (students.length == 0) {
			System.out.println();
			System.out.println("Студентів із вказаними ім'ям та прізвищем не знайдено");
		}

	}

	///////////////////////////////////////////////////////////////////////////////

	public int getNumberOfTeachersInGroup() {
		return numberOfTeachersInGroup;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public void setNumberOfTeachersInGroup(int numberOfTeachersInGroup) {
		this.numberOfTeachersInGroup = numberOfTeachersInGroup;
	}

	/**
	 * повертає масив студентів групи
	 * 
	 * @return
	 */
	public Student[] getStudents() {
		return students;
	}

	/**
	 * встановлює масив студентів групи
	 * 
	 * @param students
	 */
	public void setStudents(Student[] students) {
		this.students = students;
	}

	/**
	 * повертає номер групи
	 * 
	 * @return
	 */
	public int getGroup() {
		return group;
	}

	/**
	 * встановлює номер групи
	 * 
	 * @param group
	 */
	public void setGroup(int group) {
		this.group = group;
	}

	public Teacher[] getTeachers() {
		return teachers;
	}

	public void setTeachers(Teacher[] teachers) {
		this.teachers = teachers;
	}

	/**
	 * повертає кількість студентів
	 * 
	 * @return
	 */
	public int getNumberOfStudents() {
		return numberOfStudents;
	}

	/**
	 * встановлює кількість студентів
	 * 
	 * @param numberOfStudents
	 */
	public void setNumberOfStudents(int numberOfStudents) {
		this.numberOfStudents = numberOfStudents;
	}

}

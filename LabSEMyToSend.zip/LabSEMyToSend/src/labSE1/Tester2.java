package labSE1;

import java.io.IOException;

public class Tester2 {

	public static void main(String[] args) throws IOException {
		
		
		//Group[] groups = {new Group(1), new Group(2)};
	//	Group[][] groups1 = {groups};
		
		
		/*
		String[] strings = {"Вуля","Ґуля","Ґ'ело","Ґоола","Єєлїя", "єуля","Ґаля", "Вуля", "Єєлїя","Вуля","Єєлїя","Ґаля","Єєлїя", "Їєлїя","Аєлїя","Ґаля","Вуля","Аілїя","Ґаля","Єєлїя","Ґ'еааааааааааля", "Ґалллля"};
		
		strings = DataInput.sortNames(strings);
		for(String s: strings) {
			System.out.println(s);
		}
		*/
		Tester2 tester = new Tester2();
		University university = new University();
		tester.menu(university);

	}

	public void menu(University university) throws IOException {
		int n = 1;
		while (n != 0) {
			System.out.println();
			System.out.println("Оберіть метод для роботи з університетом:");
			System.out.println("0. Закінчити роботу з програмою");
			System.out.println("1. Додати/видалити/редагувати факультет");
			System.out.println("2. Додати/видалити/редагувати спеціальність");
			System.out.println("3. Додати/видалити/редагувати кафедру");
			System.out.println("4. Додати/видалити/редагувати студента");
			System.out.println("5. Додати/видалити/редагувати викладача");
			System.out.println();
			n = DataInput.getInt("Введіть номер методу: ");
			while (n < 0 || n > 10) {
				n = DataInput.getInt("Помилка! Введіть номер методу: ");
			}
			switch (n) {
			case 1:
				System.out.println();
				editFaculty(university);
				break;
			case 2:
				System.out.println();
				editSpecialty();
				break;
			case 3:
				System.out.println();
				editCathedra();
				break;
			case 4:
				System.out.println();
				editStudent();
				break;
			case 5:
				System.out.println();
				editTeacher();
				break;
			}
		}

	}

	

	public void editFaculty(University university) throws IOException {
		int n = 1;
		while (n != 0) {
			System.out.println("Оберіть метод для роботи з факультетом:");
			System.out.println("0. Вийти до головного меню");
			System.out.println("1. Додати факультет");
			System.out.println("2. Видалити факультет");
			System.out.println("3. Редагувати назву факультету");
			System.out.println();
			n = DataInput.getInt("Введіть номер методу: ");
			while (n < 0 || n > 3) {
				n = DataInput.getInt("Помилка! Введіть номер методу: ");
			}
			switch (n) {
			case 1:
				System.out.println();
				university.addFaculty();
				System.out.println();
				break;
			case 2:
				System.out.println();
				university.deleteFaculty();
				System.out.println();
				break;
			case 3:
				System.out.println();
				university.changeNameOfFaculty();
				System.out.println();
				break;
			}
		}

	}

	public void editSpecialty() throws IOException {
		int n = 1;
		while (n != 0) {
			System.out.println("Оберіть метод для роботи зі спеціальностями:");
			System.out.println("0. Вийти до головного меню");
			System.out.println("1. Додати спеціальності");
			System.out.println("2. Видалити спеціальність");
			System.out.println("3. Редагувати назву спеціальності");
			System.out.println();
			n = DataInput.getInt("Введіть номер методу: ");
			while (n < 0 || n > 3) {
				n = DataInput.getInt("Помилка! Введіть номер методу: ");
			}
			switch (n) {
			case 1:
				System.out.println();
				Faculty.askForFaculty("Введіть назву факультета, на який потрібно додати спеціальності: ");
				System.out.println();
				break;
			case 2:
				System.out.println();
				Faculty.askForFacultyToDelete("Введіть назву факультета, з якого потрібно видалити спеціальність: ");
				System.out.println();
				break;
			case 3:
				System.out.println();
				Faculty.askForFacultyToRename("Введіть назву факультета, у якому потрібно змінити спеціальність: ");
				System.out.println();
				break;
			}
		}

	}

	public void editCathedra() throws IOException {
		int n = 1;
		while (n != 0) {
			System.out.println("Оберіть метод для роботи з кафедрами:");
			System.out.println("0. Вийти до головного меню");
			System.out.println("1. Додати кафедри");
			System.out.println("2. Видалити кафедру");
			System.out.println("3. Редагувати назву кафедри");
			System.out.println();
			n = DataInput.getInt("Введіть номер методу: ");
			while (n < 0 || n > 3) {
				n = DataInput.getInt("Помилка! Введіть номер методу: ");
			}
			switch (n) {
			case 1:
				System.out.println();
				Faculty.askForFacultyCathedra("Введіть назву факультета, на який потрібно додати кафедри: ");
				System.out.println();
				break;
			case 2:
				System.out.println();
				Faculty.askForFacultyToDeleteCathedra("Введіть назву факультета, з якого потрібно видалити кафедру: ");
				System.out.println();
				break;
			case 3:
				System.out.println();
				Faculty.askForFacultyToRenameCathedra("Введіть назву факультета, у якому потрібно змінити кафедру: ");
				System.out.println();
				break;
			}
		}

	}

	public void editStudent() throws IOException {
		int n = 1;
		while (n != 0) {
			System.out.println("Оберіть метод для роботи зі студентами:");
			System.out.println("0. Вийти до головного меню");
			System.out.println("1. Додати студента");
			System.out.println("2. Видалити студента");
			System.out.println("3. Редагувати ім'я та прізвище студента");
			System.out.println("4. Перемістити студента");
			System.out.println("5. Знайти студента за ім'ям та прізвищем");
			System.out.println();
			n = DataInput.getInt("Введіть номер методу: ");
			while (n < 0 || n > 5) {
				n = DataInput.getInt("Помилка! Введіть номер методу: ");
			}
			switch (n) {
			case 1:
				System.out.println();
				Group.addStudent();
				System.out.println();
				break;
			case 2:
				System.out.println();
				Group.deleteStudent();
				System.out.println();
				break;
			case 3:
				System.out.println();
				Group.changeStudent();
				System.out.println();
				break;
			case 4:
				System.out.println();
				Group.replaceStudent();
				System.out.println();
				break;
			case 5:
				System.out.println();
				Group.findStudentByName();
				System.out.println();
				break;
			}
		}
	}
	
	public void editTeacher() throws IOException {
		int n = 1;
		while (n != 0) {
			System.out.println("Оберіть метод для роботи з викладачами:");
			System.out.println("0. Вийти до головного меню");
			System.out.println("1. Додати викладача");
			System.out.println("2. Видалити викладача");
			System.out.println("3. Редагувати ім'я та прізвище викладача");
			System.out.println("4. Перемістити викладача");
			System.out.println("5. Додати інформацію про викладання до викладача");
			System.out.println();
			n = DataInput.getInt("Введіть номер методу: ");
			while (n < 0 || n > 5) {
				n = DataInput.getInt("Помилка! Введіть номер методу: ");
			}
			switch (n) {
			case 1:
				System.out.println();
				Cathedra.addTeacher();
				System.out.println();
				break;
			case 2:
				System.out.println();
				Cathedra.deleteTeacher();
				System.out.println();
				break;
			case 3:
				System.out.println();
				Cathedra.changeTeacher();
				System.out.println();
				break;
			case 4:
				System.out.println();
				Cathedra.replaceTeacher();
				System.out.println();
				break;
			case 5:
				System.out.println();
				Cathedra.addSubjects();
				System.out.println();
				break;
			}
		}
	}

	

}

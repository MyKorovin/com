package labSE1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Arrays;

public final class DataInput {

	public static Long getLong() throws IOException {
		String s = getString();
		Long value = Long.valueOf(s);
		return value;
	}

	// порівнює два імені та визначає їх порядок в алфавіті
	public static int compareTo1(String string1, String string2) {
		String[] abc = { "А", "Б", "В", "Г", "Ґ", "Д", "Е", "Є", "Ж", "З", "И", "І", "Ї", "Й", "К", "Л", "М", "Н", "О",
				"П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ", "Ь", "Ю", "Я", "а", "б", "в", "г", "ґ", "д", "е",
				"є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч",
				"ш", "щ", "ь", "ю", "я" };
		int value = 0;
		int length;
		if (string1.length() <= string2.length()) {
			length = string1.length();
		} else {
			length = string2.length();
		}
		for (int i = 0; i < length; i++) {
			String s1 = "" + string1.charAt(i);
			String s2 = "" + string2.charAt(i);
			int i1 = Arrays.asList(abc).indexOf(s1);
			int i2 = Arrays.asList(abc).indexOf(s2);
			if (i1 > i2) {
				return 10;
			}
			if (i1 < i2) {
				return -10;
			}
		}
		if (string1.length() > string2.length()) {
			value = 20;
		} else if (string1.length() < string2.length()) {
			value = -20;
		}
		return value;
	}

	// порівнює два імені та визначає їх порядок в алфавіті
	public static int compareTo(String string1, String string2) {
		String[] abc = { "А", "Б", "В", "Г", "Ґ", "Д", "Е", "Є", "Ж", "З", "И", "І", "Ї", "Й", "К", "Л", "М", "Н", "О",
				"П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ", "Ь", "Ю", "Я", "а", "б", "в", "г", "ґ", "д", "е",
				"є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч",
				"ш", "щ", "ь", "ю", "я" };
		int value = 0;
		int length;
		if (string1.length() <= string2.length()) {
			length = string1.length();
		} else {
			length = string2.length();
		}
		for (int i = 0, j = 0; i < length && j < length; i++, j++) {
			String s1 = "" + string1.charAt(i);
			if (string1.charAt(i) == '\'' || string1.charAt(i) == '-') {
				i++;
				s1 = "" + string1.charAt(i);
			}
			String s2 = "" + string2.charAt(j);
			if (string2.charAt(j) == '\'' || string2.charAt(i) == '-') {
				j++;
				s2 = "" + string2.charAt(j);
			}
			int i1 = Arrays.asList(abc).indexOf(s1);
			int i2 = Arrays.asList(abc).indexOf(s2);
			if (i1 > i2) {
				return 10;
			}
			if (i1 < i2) {
				return -10;
			}
		}
		if (string1.length() > string2.length()) {
			value = 20;
		} else if (string1.length() < string2.length()) {
			value = -20;
		}
		return value;
	}

	private static Student[] sort(Student[] students) {
		if (students.length != 1) {
			for (int i = 0, k = 0; i < students.length - k; i++, k++) {
				for (int j = 0; j < students.length - k; j++) {
					if (j + 1 < students.length) {
						if (compareTo(students[j].getName(), students[j + 1].getName()) > 0) {
							Student temp = students[j];
							students[j] = students[j + 1];
							students[j + 1] = temp;
						}
					}
					if (j + 1 == students.length) {
						if (compareTo(students[j - 1].getName(), students[j].getName()) > 0) {
							Student temp = students[j];
							students[j] = students[j + 1];
							students[j + 1] = temp;
						}
					}
				}
			}
		}
		return students;
	}

	private static Teacher[] sort(Teacher[] teachers) {
		if (teachers.length != 1) {
			for (int i = 0, k = 0; i < teachers.length - k; i++, k++) {
				for (int j = 0; j < teachers.length - k; j++) {
					if (j + 1 < teachers.length) {
						if (compareTo(teachers[j].getName(), teachers[j + 1].getName()) > 0) {
							Teacher temp = teachers[j];
							teachers[j] = teachers[j + 1];
							teachers[j + 1] = temp;
						}
					}
					if (j + 1 == teachers.length) {
						if (compareTo(teachers[j - 1].getName(), teachers[j].getName()) > 0) {
							Teacher temp = teachers[j];
							teachers[j] = teachers[j + 1];
							teachers[j + 1] = temp;
						}
					}
				}
			}
		}
		return teachers;
	}

	public static Student[] sortStudentsByNames(Student[] students) {
		Student[] sortedStudents = sort(sort(students));
		return sortedStudents;
	}

	public static Teacher[] sortTeachersByNames(Teacher[] teachers) {
		Teacher[] sortedTeachers = sort(sort(teachers));
		return sortedTeachers;
	}

	// сортує масив імен студентів за алфавітом
	private static String[] sort(String[] names) {
		for (int i = 0, k = 0; i < names.length - k; i++, k++) {
			for (int j = 0; j < names.length - k; j++) {
				if (j + 1 < names.length) {
					if (compareTo(names[j], names[j + 1]) > 0) {
						String temp = names[j];
						names[j] = names[j + 1];
						names[j + 1] = temp;
					}
				}
				if (j + 1 == names.length) {
					if (compareTo(names[j - 1], names[j]) > 0) {
						String temp = names[j];
						names[j] = names[j + 1];
						names[j + 1] = temp;
					}
				}
			}
		}
		return names;
	}

	public static String[] sortNames(String[] names) {
		String[] sorted = sort(sort(names));
		return sorted;
	}

	public static char getChar(String string) throws IOException {
		System.out.println(string);
		String s = getString();
		return s.charAt(0);
	}

	public static int getInt(String string) {
		System.out.print(string);
		String s = "";
		boolean isInt = true;
		int value;
		do {
			try {
				s = getString();
				if (s.length() == 0 || s == null) {
					isInt = false;
					System.out.println("Число не введено");
					continue;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			int i = 0;
			if (s.charAt(0) == '-') {
				i = 1;
			}
			for (; i < s.length(); i++) {
				if ((s.charAt(i) > '9' || s.charAt(i) < '0')) {// && s.charAt(check) != '-') {
					isInt = false;
					System.out.println("Число введено не коректно");
					break;
				}
				isInt = true;
			}
		} while (isInt == false);
		value = Integer.valueOf(s);
		return value;
	}

	public static double getDouble(String string) {
		System.out.print(string);
		String s = "";
		boolean isDouble = true;
		double value;
		int numberOfDots = 0;
		do {
			try {
				s = getString();
				if (s.length() == 0 || s == null) {
					isDouble = false;
					System.out.println("Число не введено");
					continue;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			int i = 0;
			numberOfDots = 0;
			if (s.charAt(0) == '-') {
				i = 1;
			}
			for (; i < s.length(); i++) {
				if (s.charAt(i) == '.') {
					numberOfDots++;
				}
				if (((s.charAt(i) > '9' || s.charAt(i) < '0') && s.charAt(i) != '.') || numberOfDots > 1) {// &&
																											// s.charAt(check)
																											// != '-') {
					isDouble = false;
					System.out.println("Число введено не коректно");
					break;
				}
				isDouble = true;
			}
		} while (isDouble == false);
		value = Double.valueOf(s);
		return value;
	}

	public static String getString() throws IOException {
		String s = "";
		try {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			s = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return s;
	}

	public static boolean areDifferent(String string1, String string2) {
		if (string1.equals(string2)) {
			return false;
		}
		return true;
	}

	public static String takeInputString(String prompt) throws IOException {
		System.out.print(prompt);
		String name = DataInput.getString();
		while (name.length() == 0 || name == null || checkName(name) == false) {
			System.out.print("Помилка! " + prompt);
			name = DataInput.getString();
		}
		return name;
	}

	/**
	 * Перевіряє ім'я та прізвище на відсутність зайвих знаків
	 * 
	 * @param name
	 * @return
	 */
	private static boolean checkName(String name) {
		for (int i = 0; i < name.length(); i++) {
			if ((name.charAt(i) > ' ' && name.charAt(i) < '\'') || (name.charAt(i) > '-' && name.charAt(i) <= '@')
					|| (name.charAt(i) >= '[' && name.charAt(i) <= '`')
					|| (name.charAt(i) >= '{' && name.charAt(i) <= '~')) {
				return false;
			}
		}
		return true;
	}

}

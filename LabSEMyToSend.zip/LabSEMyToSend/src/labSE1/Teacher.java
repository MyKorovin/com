package labSE1;

import java.io.IOException;
import java.util.Arrays;

public class Teacher {

	private String name;
	private String cathedra;
	private String faculty;
	public static int uniqueCode;
	private final int code;
	private boolean teaches = false;

	/*
	 * 
	 * public boolean equals(Teacher teacher) { if (name.equals(teacher.getName()))
	 * { if (cathedra.equals(teacher.getCathedra())) { if
	 * (faculty.equals(teacher.getFaculty())) { return true; } } } return false; }
	 */

	
	public boolean equals(Teacher teacher) {
		if (code == teacher.getCode() && name.equals(teacher.getName()))
			return true;
		return false;
	}

	public int getCode() {
		return code;
	}

	public static int getUniqueCode() {
		return uniqueCode;
	}

	public static void setUniqueCode(int uniqueCode) {
		Teacher.uniqueCode = uniqueCode;
	}

	/**
	 * конструктор без параметрів, що встановлює ім'я та прізвище викладача
	 * 
	 * @throws IOException
	 */
	public Teacher() throws IOException {
		System.out.println();
		this.name = DataInput.takeInputString("Введіть прізвище та ім'я викладача: ");
		code = uniqueCode;
		uniqueCode++;
	}

	public Teacher(Cathedra cathedra) {
		code = uniqueCode;
		uniqueCode++;
	}
	
	public Teacher(String s) {
		code = uniqueCode;
		uniqueCode++;
	}

	public boolean doesTeach() {
		return teaches;
	}

	public void setDoesTeach() {
		teaches = true;
	}

	/**
	 * повертає назву факультета
	 * 
	 * @return
	 */
	public String getFaculty() {
		return faculty;
	}

	/**
	 * встановлює назву факультета
	 * 
	 * @param faculty
	 */
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	/**
	 * повертає назву кафедри
	 * 
	 * @return
	 */
	public String getCathedra() {
		return cathedra;
	}

	/**
	 * встановлює назву кафедри
	 * 
	 * @param cathedra
	 */
	public void setCathedra(String cathedra) {
		this.cathedra = cathedra;
	}

	/**
	 * конструктор з параметром, що встановлює ім'я та прізвище викладача
	 * 
	 * @param name
	 */
	

	/**
	 * повертає ім'я та прізвище викладача
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * встановлює ім'я та прізвище викладача
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/// ????????????????????????
	public String toString() {
		return this.getName() + " працює на факультеті " + this.getFaculty() + " на кафедрі " + this.getCathedra();
	}

}

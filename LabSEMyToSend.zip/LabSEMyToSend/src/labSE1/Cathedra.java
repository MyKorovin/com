package labSE1;

import java.io.IOException;
import java.util.Arrays;

/**
 * @author illia_sitkov
 *
 */
public class Cathedra {

	private String name;
	private int numberOfTeachers;
	Teacher[] teachers = new Teacher[0];

	/**
	 * повертає кількість вчителів
	 * 
	 * @return
	 */
	public int getNumberOfTeachers() {
		return numberOfTeachers;
	}

	/**
	 * встановлює кількість вчителів
	 * 
	 * @param numberOfTeachers
	 */
	public void setNumberOfTeachers(int numberOfTeachers) {
		this.numberOfTeachers = numberOfTeachers;
	}

	/**
	 * повертає масив учителів
	 * 
	 * @return
	 */
	public Teacher[] getTeachers() {
		return teachers;
	}

	/**
	 * приймає та встановлює масив учителів
	 * 
	 * @param teachers
	 */
	public void setTeachers(Teacher[] teachers) {
		this.teachers = teachers;
	}

	/**
	 * конструктор, що питає назву кафедри
	 * 
	 * @throws IOException
	 */
	public Cathedra() throws IOException {
		name = DataInput.takeInputString("Введіть назву кафедри: ");
	}

	//////////////////////////////////////////////////////////////////////////////////////

	public static boolean teachersPresent(Cathedra cathedra) {
		if (cathedra.getNumberOfTeachers() != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодного викладача!");
		}
		return false;
	}

	/**
	 * метод, що питає факультет та кафедру, на які додати учителя
	 * 
	 * @throws IOException
	 */
	public static void addTeacher() throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, на який потрібно додати викладача: ");
			if (faculty != null && Faculty.cathedrasPresent(faculty)) {
				Cathedra cathedra = askForCathedra(faculty, "Введіть кафедру, на яку потрібно додати викладача: ");
				if (cathedra != null) {
					addTeacher(cathedra, faculty);
				}
			}
		}
	}

	/**
	 * метод, що питає факультет та кафедру, з яких видалити учителя
	 * 
	 * @throws IOException
	 */
	public static void deleteTeacher() throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent() && University.teachersPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, з якого потрібно видалити викладача: ");
			if (faculty != null && Faculty.cathedrasPresent(faculty)) {
				Cathedra cathedra = askForCathedra(faculty, "Введіть кафедру, з якої потрібно видалити викладача: ");
				if (cathedra != null && teachersPresent(cathedra)) {
					deleteTeacher(cathedra);
				}
			}
		}
	}

	/**
	 * метод, що питає факультет та кафедру, на яких змінити учителя
	 * 
	 * @throws IOException
	 */
	public static void changeTeacher() throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent() && University.teachersPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, на якому потрібно змінити викладача: ");
			if (faculty != null && Faculty.cathedrasPresent(faculty)) {
				Cathedra cathedra = askForCathedra(faculty, "Введіть кафедру, на якій потрібно змінити викладача: ");
				if (cathedra != null && teachersPresent(cathedra)) {
					changeTeacher(cathedra);
				}
			}
		}
	}
	
	/**додає інформацію про викладання до викладача
	 * @throws IOException
	 */
	public static void addSubjects() throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent() && University.teachersPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, на якому до викладача треба додати інформацію про викладання: ");
			if (faculty != null && Faculty.cathedrasPresent(faculty) && Faculty.teachersPresent(faculty)) {
				Cathedra cathedra = askForCathedra(faculty, "Введіть кафедру, на якій до викладача треба додати інформацію про викладання: ");
				if (cathedra != null && teachersPresent(cathedra)) {
					printAllTeachers(cathedra);
					String name = DataInput
							.takeInputString("Введіть ім'я та прізвище викладача, якому треба додати інформацію про викладання: ");
					Teacher teacher = findTeacherInCathedra(cathedra, name);
					if (teacher != null) {
						addSubjects(teacher);
					}
				}
			}
		}
	}
	
	/**додає інформацію про викладання до викладача
	 * @param teacher
	 * @throws IOException
	 */
	private static void addSubjects(Teacher teacher) throws IOException {
		System.out.println();
		System.out.println("Додавання інформації про викладання");
		if (University.facultiesPresent() && University.specialtiesPresent()) {
			while (true) {
			Faculty faculty = askForFaculty("Введіть назву факультету, на якому викладає викладач: ");
			if (faculty != null && Faculty.specialtiesPresent(faculty)) {
				Specialty specialty = Group.askForSpecialty(faculty,
						"Введіть спеціальність, на якій викладає викладач: ");
				if (specialty != null) {
					Course course = Group.askForCourse(specialty, "Введіть курс (1 - 6), на якому викладає викладач: ");
					Group group = Group.askForGroup(course, "Введіть номер групи (1 - 6), у якій викладає викладач: ");
					addTeacher(teacher, group, course, specialty, faculty);
				}
			}
			String prod = DataInput.takeInputString("Продовжити додавання груп? так/ні ");
			if (prod.charAt(0) == 'н')
				break;
		}
		}
	}
	
	
	
	
	

	/**переміщує викладача
	 * @throws IOException
	 */
	public static void replaceTeacher() throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent() && University.teachersPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, з якого треба перемістити викладача: ");
			if (faculty != null && Faculty.cathedrasPresent(faculty) && Faculty.teachersPresent(faculty)) {
				Cathedra cathedra = askForCathedra(faculty, "Введіть кафедру, з якої треба перемістити викладача: ");
				if (cathedra != null && teachersPresent(cathedra)) {
					printAllTeachers(cathedra);
					System.out.println();
					String name = DataInput
							.takeInputString("Введіть ім'я та прізвище викладача, якого треба перемістити: ");
					Teacher teacher = findTeacherInCathedra(cathedra, name);
					if (teacher != null) {
						replaceTeacher(teacher);
					}
				}
			}
		}
	}
	
	/**переміщує викладача
	 * @param teacher
	 * @throws IOException
	 */
	private static void replaceTeacher(Teacher teacher) throws IOException {
		Faculty faculty = askForFaculty("Введіть назву факультету, на який потрібно перемістити викладача: ");
		if (faculty != null && Faculty.cathedrasPresent(faculty)) {
			Cathedra cathedra = askForCathedra(faculty, "Введіть кафедру, на яку потрібно перемістити викладача: ");
			if (cathedra != null) {
				replaceTeacher(teacher, faculty, cathedra);
			}
		}
	}

	
	/**
	 * безпосередньо переміщує викладача на необхідну кафедру
	 * 
	 * @param teacher
	 * @param faculty
	 * @param cathedra
	 */
	private static void replaceTeacher(Teacher teacher, Faculty faculty, Cathedra cathedra) {
		boolean needsReplace = true;
		if (teacher.getFaculty().equals(faculty.getName())) {
			if (teacher.getCathedra().equals(cathedra.getName())) {
				System.out.println();
				System.out.println("Викладач вже знаходиться тут");
				needsReplace = false;
			}
		}

		if (needsReplace == true) {
			Teacher temp = teacher;
			deleteFound(teacher);
			addOneTeacher(temp, faculty, cathedra);

		}
	}
	
	/**
	 * видаляє викладача з таким ім'ям
	 * 
	 * @param name
	 */
	private static void deleteFound(Teacher teacher) {
		for (Faculty faculty : University.getFaculties()) {
			for (Cathedra cathedra : faculty.getCathedras()) {
				for (Teacher teacherOld : cathedra.getTeachers()) {
					if (teacher.equals(teacherOld)) {
						Teacher[] teachers = cathedra.getTeachers();
						teachers[Arrays.asList(teachers).indexOf(teacherOld)] = null;
						cathedra.setTeachers(resortTeachers(teachers));
						cathedra.setNumberOfTeachers(cathedra.getNumberOfTeachers() - 1);
						break;
					}
				}
			}
		}
	}
	
	/**
	 * додає викладача на кафедру
	 * 
	 * @param teacher
	 * @param faculty
	 * @param cathedra
	 */
	private static void addOneTeacher(Teacher teacher, Faculty faculty, Cathedra cathedra) {
		Teacher[] temp = cathedra.getTeachers();
		Teacher[] teachers = new Teacher[cathedra.getNumberOfTeachers() + 1];
		//teachers[cathedra.getNumberOfTeachers()] = new Teacher(cathedra);
		teachers[cathedra.getNumberOfTeachers()] = teacher;
		//teachers[cathedra.getNumberOfTeachers()].setName(teacher.getName());
		teachers[cathedra.getNumberOfTeachers()].setCathedra(cathedra.getName());
		teachers[cathedra.getNumberOfTeachers()].setFaculty(faculty.getName());
		cathedra.setNumberOfTeachers(cathedra.getNumberOfTeachers() + 1);
		for (int i = 0; i < temp.length; i++) {
			teachers[i] = temp[i];
		}
		cathedra.setTeachers(teachers);
	}
	
	
	/**видаляє інформацію про викладання у викладача
	 * @throws IOException
	 */
	public static void deleteSubjects() throws IOException {
		if (University.facultiesPresent() && University.cathedrasPresent() && University.teachersPresent()) {
			Faculty faculty = askForFaculty("Введіть назву факультету, на якому у викладача треба видалити інформацію про викладання: ");
			if (faculty != null && Faculty.cathedrasPresent(faculty) && Faculty.teachersPresent(faculty)) {
				Cathedra cathedra = askForCathedra(faculty, "Введіть кафедру, на якій у викладача треба видалити інформацію про викладання: ");
				if (cathedra != null && teachersPresent(cathedra)) {
					printAllTeachers(cathedra);
					String name = DataInput
							.takeInputString("Введіть ім'я та прізвище викладача, у якого треба видалити інформацію про викладання: ");
					Teacher teacher = findTeacherInCathedra(cathedra, name);
					if (teacher != null) {
						deleteSubjects(teacher);
					}
				}
			}
		}
	}
	
	
	
	/**видаляє викладача з груп, де він викладав
	 * @param teacher
	 */
	private static void deleteSubjects(Teacher teacher) {
		for (Faculty f: University.getFaculties()) {
			for (Specialty s: f.getSpecialties()) {
				for (Course c: s.getCourses()) {
					for (Group g: c.getGroups()) {
						for (Teacher t: g.getTeachers()) {
							if (t != null && t.equals(teacher)) {
								Teacher[] teachers = g.getTeachers();
								teachers[Arrays.asList(teachers).indexOf(t)] = null;
								g.setNumberOfTeachersInGroup(g.getNumberOfTeachersInGroup() - 1);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * шукає викладача на факультеті за ім'ям
	 * 
	 * @param name
	 * @return
	 * @throws IOException
	 */
	private static Teacher findTeacherInCathedra(Cathedra cathedra, String name) throws IOException {
		for (Teacher teacher : cathedra.getTeachers()) {
			if (teacher.getName().equals(name)) {
				return teacher;
			}
		}
		System.out.println();
		System.out.println("Викладача з таким ім'ям та прізвищем не було знайдено!");
		return null;
	}

	/**
	 * змінює ім'я учителя
	 * 
	 * @param cathedra
	 * @throws IOException
	 */
	private static void changeTeacher(Cathedra cathedra) throws IOException {
		Teacher[] teachers = cathedra.getTeachers();
		printAllTeachers(cathedra);
		boolean found = false;
		System.out.println();
		String name = DataInput.takeInputString("Введіть ім'я та прізвище викладача, якого потрібно змінити: ");
		for (Teacher teacher : teachers) {
			if (teacher.getName().equals(name)) {
				String newName = DataInput.takeInputString("Введіть нові ім'я та прізвище викладача: ");
				teacher.setName(newName);
				System.out.println();
				System.out.println("Викладача перейменовано!");
				found = true;
				printAllTeachers(cathedra);
				break;
			}
		}
		if (found == false) {
			System.out.println();
			System.out.println("Викладача з таким ім'ям та прізвищем не знайдено!");
		}
	}

	/**
	 * видаляє учителя з кафедри
	 * 
	 * @param cathedra
	 * @throws IOException
	 */
	private static void deleteTeacher(Cathedra cathedra) throws IOException {
		printAllTeachers(cathedra);
		Teacher[] teachers = cathedra.getTeachers();
		boolean found = false;
		String name = DataInput.takeInputString("Введіть ім'я та прізвище викладача, якого потрібно видалити: ");
		for (Teacher teacher : teachers) {
			if (teacher.getName().equals(name)) {
				teachers[Arrays.asList(teachers).indexOf(teacher)] = null;
				System.out.println();
				System.out.println("Викладача видалено!");
				cathedra.setTeachers(resortTeachers(teachers));
				found = true;
				cathedra.setNumberOfTeachers(cathedra.getNumberOfTeachers() - 1);
				printAllTeachers(cathedra);
				break;
			}
		}
		if (found == false) {
			System.out.println();
			System.out.println("Викладача з таким ім'ям та прізвищем не знайдено!");
		}
	}

	/**
	 * сортує учителів кафедри
	 * 
	 * @param teachers
	 * @return
	 */
	private static Teacher[] resortTeachers(Teacher[] teachers) {
		Teacher[] temp = teachers;
		teachers = new Teacher[0];
		for (int i = 0, j = 0; i < temp.length; i++) {
			if (temp[i] != null) {
				Teacher[] temp1 = teachers;
				teachers = new Teacher[teachers.length + 1];
				teachers[j] = temp[i];
				for (int k = 0; k < temp1.length; k++) {
					teachers[k] = temp1[k];
				}
				j++;
			}
		}
		return teachers;
	}

	/**
	 * додає учителів на кафедру
	 * 
	 * @param neededCathedra
	 * @param faculty
	 * @throws IOException
	 */
	private static void addTeacher(Cathedra neededCathedra, Faculty faculty) throws IOException {
		Teacher[] teachers = neededCathedra.getTeachers();
		printAllTeachers(neededCathedra);
		while (true) {
			Teacher[] temp = teachers;
			teachers = new Teacher[temp.length + 1];
			teachers[neededCathedra.getNumberOfTeachers()] = new Teacher();
			teachers[neededCathedra.getNumberOfTeachers()].setCathedra(neededCathedra.getName());
			teachers[neededCathedra.getNumberOfTeachers()].setFaculty(faculty.getName());
			for (int i = 0; i < temp.length; i++) {
				teachers[i] = temp[i];
			}
			addSubjects(teachers[neededCathedra.getNumberOfTeachers()]);
				
			neededCathedra.setNumberOfTeachers(neededCathedra.getNumberOfTeachers() + 1);
			String prod = DataInput.takeInputString("Продовжити додавання викладачів? так/ні ");
			if (prod.charAt(0) == 'н')
				break;
		}
		neededCathedra.setTeachers(teachers);
		printAllTeachers(neededCathedra);
	}
	
	
	
	
	/**додає викладача в групу викладання
	 * @param teacher
	 * @param group
	 * @param course
	 * @param specialty
	 * @param faculty
	 * @throws IOException
	 */
	private static void addTeacher(Teacher teacher, Group group, Course course, Specialty specialty, Faculty faculty) throws IOException {
		if (differentGroup(group, teacher)) {
		Teacher[] teachers = group.getTeachers();
		//printAllTeac(neededGroup);
			Teacher[] temp = teachers;
			teachers = new Teacher[temp.length + 1];
			teachers[group.getNumberOfTeachersInGroup()] = teacher;
			teacher.setDoesTeach();
			//students[neededGroup.getNumberOfStudents()].setGroup(neededGroup.getGroup());
			//students[neededGroup.getNumberOfStudents()].setCourse(course.getCourse());
			//students[neededGroup.getNumberOfStudents()].setSpecialty(specialty.getName());
			//students[neededGroup.getNumberOfStudents()].setFaculty(faculty.getName());
			group.setNumberOfTeachersInGroup(group.getNumberOfTeachersInGroup() + 1);
			for (int i = 0; i < temp.length; i++) {
				teachers[i] = temp[i];
		}
		group.setTeachers(teachers);
		}
		else {
			System.out.println("Викладач уже викладає в цій групі!");
		}
	}
	
	
	/**перевіряє, чи не в ту саму групу додають викладача
	 * @param group
	 * @param teacher
	 * @return
	 */
	private static boolean differentGroup(Group group, Teacher teacher) {
		for (Teacher t: group.getTeachers()) {
			if (t.equals(teacher)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * друкує всіх вчителів кафедри без інформації про них
	 * 
	 * @param cathedra
	 */
	/*
	public static void printAllTeachers2(Cathedra cathedra) {
		Teacher[] teachers = cathedra.getTeachers();
		System.out.println();
		System.out.println("Список викладачів кафедри " + cathedra.getName() + ": ");
		for (Teacher teacher : teachers) {
			if (teacher != null) {
				System.out.println((Arrays.asList(teachers).indexOf(teacher) + 1) + ". " + teacher.toString());
				if (teacher.doesStudy()) {
					for (String s : teacher.getTeachesAt()) {
						if (s != null) {
							System.out.println(s);
						}
					}
				} else {
					System.out.println("Інформації про викладання не додано");
				}
			}
		}
		if (teachers.length == 0) {
			System.out.println("Не додано жодного викладача");
		}
	}
	*/

	/**
	 * друкує всіх вчителів кафедри без інформації про них
	 * 
	 * @param cathedra
	 */
	public static void printAllTeachersQ(Cathedra cathedra) {
		Teacher[] teachers = cathedra.getTeachers();
		System.out.println();
		System.out.println("Список викладачів кафедри " + cathedra.getName() + ": ");
		for (Teacher teacher : teachers) {
			if (teacher != null)
				System.out.println((Arrays.asList(teachers).indexOf(teacher) + 1) + ". " + teacher.getName());
		}
		if (teachers.length == 0) {
			System.out.println("Не додано жодного викладача");
		}
	}

	/**
	 * друкує всіх вчителів кафедри з інформацією про них
	 * 
	 * @param cathedra
	 */
	public static void printAllTeachersExt(Cathedra cathedra) {
		Teacher[] teachers = cathedra.getTeachers();
		System.out.println();
		System.out.println("Список викладачів кафедри " + cathedra.getName() + ": ");
		for (Teacher teacher : teachers) {
			if (teacher != null)
				System.out.println((Arrays.asList(teachers).indexOf(teacher) + 1) + ". " + teacher.getName()
						+ " викладає на факультеті " + teacher.getFaculty() + " на кафедрі " + teacher.getCathedra());
		}
		if (teachers.length == 0) {
			System.out.println("Не додано жодного викладача");
		}
	}

	/**
	 * запитує у користувача необхідний факультет для додавання вчителів
	 * 
	 * @param prompt
	 * @return
	 * @throws IOException
	 */
	private static Faculty askForFaculty(String prompt) throws IOException {
		University.printAllFaculties();
		Faculty neededFaculty = null;
		String name = DataInput.takeInputString(prompt);
		Faculty[] faculties = University.getFaculties();
		for (Faculty faculty : faculties) {
			if (faculty.getName().equals(name)) {
				neededFaculty = faculty;
				return neededFaculty;
			}
		}
		if (neededFaculty == null) {
			System.out.println();
			System.out.println("Факультету з такою назвою не знайдено!");
		}
		return null;
	}

	/**
	 * запитує користувача кафедру для додавання учителів
	 * 
	 * @param neededFaculty
	 * @param prompt
	 * @return
	 * @throws IOException
	 */
	private static Cathedra askForCathedra(Faculty neededFaculty, String prompt) throws IOException {
		Faculty.printAllCathedras(neededFaculty);
		Cathedra neededCathedra = null;
		String name = DataInput.takeInputString(prompt);
		Cathedra[] cathedras = neededFaculty.getCathedras();
		for (Cathedra cathedra : cathedras) {
			if (cathedra.getName().equals(name)) {
				neededCathedra = cathedra;
				return neededCathedra;
			}
		}
		if (neededCathedra == null) {
			System.out.println();
			System.out.println("Не знайдено вказану кафедру!");
		}
		return null;
	}

	/**друкує вчителя та інформацію про викладання
	 * @param cathedra
	 */
	public static void printAllTeachers(Cathedra cathedra) {
		System.out.println();
		System.out.println("Список викладачів кафедри " + cathedra.getName() + ": ");
		for (Teacher teacher : cathedra.getTeachers()) {
			System.out.println((Arrays.asList(cathedra.getTeachers()).indexOf(teacher) + 1) + ". " + teacher.getName()
					+ " працює на факультеті " + teacher.getFaculty() + " на кафедрі " + teacher.getCathedra());
			if (teacher.doesTeach()) {
				boolean found = false;
				for (Faculty faculty : University.getFaculties()) {
					for (Specialty specialty : faculty.getSpecialties()) {
						for (Course course : specialty.getCourses()) {
							for (Group group : course.getGroups()) {
								for (Teacher t : group.getTeachers()) {
									if (t.equals(teacher)) {
										found = true;
										System.out.println("Викладач " + teacher.getName() + " викладає на факультеті "
												+ group.getCourse().getSpecialty().getFaculty().getName()
												+ " на спеціальності " + group.getCourse().getSpecialty().getName()
												+ " на курсі " + group.getCourse().getCourse() + " у групі "
												+ group.getGroup());
									}
								}
							}
						}
					}
				}
				if (found == false) {
					System.out.println("Інформації про викладання не додано");
				}
			}
			else {
				System.out.println("Інформації про викладання не додано");
			}
		}
	}
	

	/**
	 * повертає назву кафедри
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * встановлює назву кафедри
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

}

package labSE1;

import java.io.IOException;
import java.util.Arrays;

/**
 * @author illia_sitkov
 *
 */
public class University {
	// масив факультетів
	private static Faculty[] faculties = new Faculty[0];

	/**рахує ксть кафедр в університеті
	 * @return
	 */
	public static int genNumOfCath() {
		int num = 0;
		for (Faculty faculty : faculties) {
			for (Cathedra c: faculty.getCathedras()) {
				if (c!=null) num++;
			}
		}
		return num;
	}

	/**рахує ксть спеціальностей в університеті
	 * @return
	 */
	public static int genNumOfSp() {
		int num = 0;
		for (Faculty faculty : faculties) {
			for (Specialty s: faculty.getSpecialties()) {
				if (s!=null) num++;
			}
		}
		return num;
	}

	/**рахує ксть студентів в університеті
	 * @return
	 */
	public static int genNumOfSt() {
		int num = 0;
		for (Faculty faculty : faculties) {
			for (Specialty specialty : faculty.getSpecialties()) {
				for (Course course : specialty.getCourses()) {
					for (Group group : course.getGroups()) {
						num += group.getNumberOfStudents();
					}
				}
			}
		}
		return num;
	}

	/**рахує ксть вчителів в університеті
	 * @return
	 */
	public static int genNumOTeach() {
		int num = 0;
		for (Faculty faculty : faculties) {
			for (Cathedra cathedra : faculty.getCathedras()) {
				for (Teacher t: cathedra.getTeachers()) {
					if (t != null) num++;
				}
			}
		}
		return num;
	}

	/**перевіряє, чи є факультети в університеті
	 * @return
	 */
	public static boolean facultiesPresent() {
		if (Faculty.numberOfFaculties != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодного факультету! Спочатку додайте факультет!");
		}
		return false;
	}

	/**перевіряє, чи є кафедри в університеті
	 * @return
	 */
	public static boolean cathedrasPresent() {
		if (genNumOfCath() != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодної кафедри! Спочатку додайте кафедру");
		}
		return false;
	}
	/**перевіряє, чи є спеціальності в університеті
	 * @return
	 */
	public static boolean specialtiesPresent() {
		if (genNumOfSp() != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодної спеціальності! Спочатку додайте спеціальність!");
		}
		return false;
	}
	/**перевіряє, чи є вчителі в університеті
	 * @return
	 */
	public static boolean teachersPresent() {
		if (genNumOTeach() != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодного викладача! Спочатку додайте викладача!");
		}
		return false;
	}
	/**перевіряє, чи є студенти в університеті
	 * @return
	 */
	public static boolean studentsPresent() {
		if (genNumOfSt() != 0) {
			return true;
		} else {
			System.out.println();
			System.out.println("Не додано жодного студента! Спочатку додайте студента!");
		}
		return false;
	}

	/**
	 * метод, що дозволяє додавати факультети
	 * 
	 * @throws IOException
	 */
	public void addFaculty() throws IOException {
		while (true) {
			Faculty[] temp = faculties;
			faculties = new Faculty[faculties.length + 1];
			faculties[Faculty.numberOfFaculties] = new Faculty();
			String name = faculties[Faculty.getNumberOfFaculties()].getName();
			while (Faculty.areDifferent(temp, name) == false) {
				name = DataInput.takeInputString("Такий факультет вже існує! Введіть новий факультет: ");
			}
			faculties[Faculty.getNumberOfFaculties()].setName(name);
			Faculty.numberOfFaculties++;
			for (int i = 0; i < temp.length; i++) {
				faculties[i] = temp[i];
			}
			String prod = DataInput.takeInputString("Продовжити введення? так/ні ");
			if (prod.charAt(0) == 'н')
				break;
		}
		printAllFaculties();
	}

	/**
	 * метод, що дозволяє видаляти факультети
	 * 
	 * @throws IOException
	 */
	public void deleteFaculty() throws IOException {
		if (facultiesPresent()) {
			printAllFaculties();
			boolean found = false;
			boolean delete = true;
			String name = DataInput.takeInputString("Введіть назву факультету, який потрібно видалити: ");
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					System.out.println();
					System.out.println(
							"Разом з факультетом буде ВИДАЛЕНО ВСІ спеціальності, курси, групи та записаних до них студентів!");
					System.out.print("Точно бажаєте ВИДАЛИТИ факультет? (так/ні): ");
					String conf = DataInput.getString();
					if (conf.charAt(0) == 'н') {
						delete = false;
						break;
					}
					System.out.println();
					System.out.print("Факультет видалено");
					System.out.println();
					faculties[Arrays.asList(faculties).indexOf(faculty)] = null;
					resortFaculties();
					found = true;
					Faculty.numberOfFaculties--;
					printAllFaculties();
					break;
				}
			}
			if (found == false && delete == true) {
				System.out.println();
				System.out.println("факультету з такою назвою не знайдено!");
			}
		}
	}

	/**
	 * метод, що відновлює правильний порядок факультетів після видалення
	 * 
	 */
	private void resortFaculties() {
		Faculty[] temp = faculties;
		faculties = new Faculty[0];
		for (int i = 0, j = 0; i < temp.length; i++) {
			if (temp[i] != null) {
				Faculty[] temp1 = faculties;
				faculties = new Faculty[faculties.length + 1];
				faculties[j] = temp[i];
				for (int k = 0; k < temp1.length; k++) {
					faculties[k] = temp1[k];
				}
				j++;
			}
		}
	}

	/**
	 * метод, що дозволяє змінювати назву факультету
	 * 
	 * @throws IOException
	 */
	public void changeNameOfFaculty() throws IOException {
		if (facultiesPresent()) {
			printAllFaculties();
			boolean found = false;
			String name = DataInput.takeInputString("Введіть назву факультету, який потрібно перейменувати: "); // номер
			for (Faculty faculty : faculties) {
				if (faculty.getName().equals(name)) {
					faculty.setName("");
					String newName = DataInput.takeInputString("Введіть нову назву факультету: ");
					while (Faculty.areDifferent(faculties, newName) == false) {
						newName = DataInput
								.takeInputString("Такий факультет вже існує! Введіть нову назву факультету: ");
					}
					faculty.setName(newName);
					renewNameOfFacultyInStudents();
					renewNameOfFacultyInTeachers();
					found = true;
					printAllFaculties();
					break;
				}
			}
			if (found == false) {
				System.out.println();
				System.out.println("Факультету з такою назвою не знайдено!");
			}
		}
	}

	/**
	 * перейменовує назву факультету в студентів після зміни назви факультету
	 * 
	 */
	private void renewNameOfFacultyInStudents() {
		for (Faculty faculty : faculties) {
			for (Specialty specialty : faculty.getSpecialties()) {
				for (Course course : specialty.getCourses()) {
					for (Group group : course.getGroups()) {
						for (Student student : group.getStudents()) {
							student.setFaculty(faculty.getName());
						}
					}
				}
			}
		}
	}

	/**
	 * перейменовує назву факультету у викладачів після зміни назви факультету
	 * 
	 */
	private void renewNameOfFacultyInTeachers() {
		for (Faculty faculty : faculties) {
			for (Cathedra cathedra : faculty.getCathedras()) {
				for (Teacher teacher : cathedra.getTeachers()) {
					teacher.setFaculty(faculty.getName());
				}
			}
		}
	}

	/**
	 * метод, що друкує всі факультети
	 */
	public static void printAllFaculties() {
		System.out.println();
		System.out.println("Список факультетів університету: ");
		for (Faculty s : faculties) {
			if (s != null)
				System.out.println((Arrays.asList(faculties).indexOf(s) + 1) + ". " + s.getName());
		}
		if (facultiesPresent()==false) {
			System.out.println("Не додано жодного факультету");
		}
	}


///////////////////////////////////////////////////////////
	
	public static Student[] sortStudentsbyNames(Student[] students){
	    int length = students.length;
	    Student[] studentsSorted = new Student[length];
	    
	    for (int i = 0; i < length; i++){
	      studentsSorted[i] = students[i];
	      }
	    
	    for (int j = 0; j < length; j++) {
	            for (int i = j + 1; i < length; i++) {
	                if (DataInput.compareTo(studentsSorted[i].getName(), studentsSorted[j].getName()) < 0){  
	                  Student st = new Student("");
	                    st = studentsSorted[j];
	                    studentsSorted[j] = studentsSorted[i];
	                    studentsSorted[i] = st;
	                }
	            }
	        } 
	    return studentsSorted;
	  }
	
	public static Teacher[] sortTeachersbyNames(Teacher[] teachers){
	    int length = teachers.length;
	    Teacher[] teachersSorted = new Teacher[length];
	    
	    for (int i = 0; i < length; i++){
	      teachersSorted[i] = teachers[i];
	      }
	    for (int j = 0; j < length; j++) {
	            for (int i = j + 1; i < length; i++) {
	                if (teachersSorted[i].getName().compareTo(teachersSorted[j].getName()) < 0) {
	                  Teacher t = new Teacher("");
	                  	t = teachersSorted[j];
	                    teachersSorted[j] = teachersSorted[i];
	                    teachersSorted[i] = t;
	                }
	            }
	        }
	    return teachersSorted;
	  }
//////////////////////////////////////////////////////////
	
			public static void printAllStudentsSortedByCourses() throws IOException{
			    if (faculties.length != 0) {
			      boolean areStudentsPresent = false;
			      for (Faculty faculty : getFaculties()) {
			        if (faculty.getNumberOfStudentsOnFaculty() != 0){// Faculty.studentsPresent(faculty)
			          areStudentsPresent = true;
			          break;
			        }
			      }
			      if (areStudentsPresent == true){
			        System.out.println("Список студентів університету впорядкованих за курсами:");
			        for (int i = 1; i <= 6; i++){
			          System.out.println();
			          System.out.println("Студенти " + i + " курсу:");
			          System.out.println();
			          int numberOfStudent = 1;
			          for (Faculty faculty : getFaculties()) {
			            for (Specialty specialty : faculty.getSpecialties()) {
			              for (Course course : specialty.getCourses()) {
			                if (course.getCourse() == i){
			                  for (Group group : course.getGroups()) {
			                    for (Student student : group.getStudents()) {
			                      System.out.println(numberOfStudent + ". " + student.toString());
			                      numberOfStudent ++;
			                    }
			                  }
			                }  
			              }
			            }  
			          }
			        }
			      } else {
			        System.out.println();
			        System.out.println("В університеті немає жодного студента!");
			      }
			    } else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }
			  }
			  
			  public void printAllStudentsOnFaculty() throws IOException{
			    
			    if (faculties.length != 0) {
			      printAllFaculties();
			      boolean found = false;
			      String name = DataInput.takeInputString("Введіть назву факультета для виведення всіх студентів за алфавітом: ");
			      for (Faculty faculty : faculties) {
			        if (faculty.getName().equals(name)) {
			          Student students[] = sortStudentsbyNames(Faculty.createArrayOfStudentsOfFaculty(faculty));
			          if (faculty.getNumberOfStudentsOnFaculty() != 0){//есть метод Faculty.studentsPresent(Faculty faculty)
			            System.out.println("Список студентів факультету " + faculty.getName() + " за алфавітом: ");
			            System.out.println();
			            for (Student s : students) {
			              if (s != null)
			                System.out.println((Arrays.asList(students).indexOf(s) + 1) + ". " + s.toString());
			            }
			          }
			          else {
			            System.out.println();
			            System.out.println("На факультет не додано жодного студента!");
			          }
			          found = true;
			          break;
			        }
			      }
			      if (found == false) {
			        System.out.println();
			        System.out.println("Факультета з такою назвою не знайдено!");
			      }
			    } else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }
			  }
			  
			  
			  
			  
			    public void printAllTeachersOnFaculty() throws IOException{
			    
			    if (faculties.length != 0) {
			      printAllFaculties();
			      boolean found = false;
			      String name = DataInput.takeInputString("Введіть назву факультета для виведення всіх викладачів за алфавітом: ");
			      for (Faculty faculty : faculties) {
			        if (faculty.getName().equals(name)) {
			          Teacher teachers[] = sortTeachersbyNames(Faculty.getTeachersOfFaculty(faculty));
			          if (faculty.getNumberOfTeachersOnFaculty() != 0){ // есть метод Faculty.teachersPresent(Faculty faculty)
			System.out.println("Список викладачів факультету " + faculty.getName() + " за алфавітом: ");
			            System.out.println();
			            for (Teacher t : teachers) {
			              if (t != null)
			                System.out.println((Arrays.asList(teachers).indexOf(t) + 1) + ". " + t.toString());
			            }
			          }
			          else {
			            System.out.println();
			            System.out.println("На факультет не додано жодного викладача!");
			          }
			          found = true;
			          break;
			        }
			      }
			      if (found == false) {
			        System.out.println();
			        System.out.println("Факультета з такою назвою не знайдено!");
			      }
			    } else {
			      System.out.println();
			      System.out.println("Не додано жодного факультета! Спочатку додайте факультет!");
			    }
			  }
			  

///////////////////////////////////////////////////////////

	/**
	 * повертає факультети
	 * 
	 * @return
	 */
	public static Faculty[] getFaculties() {
		return faculties;
	}

	/**
	 * встановлює факультети
	 * 
	 * @param faculties
	 */
	public void setFaculties(Faculty[] faculties) {
		University.faculties = faculties;
	}

}
